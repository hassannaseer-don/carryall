import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Safe Lazy Gemini Client
  function getGeminiClient(): GoogleGenAI | null {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) return null;
    return new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }

  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', brand: 'bag.Ze', hasGeminiKey: !!process.env.GEMINI_API_KEY });
  });

  // AI Stylist Endpoint
  app.post('/api/ai/stylist', async (req, res) => {
    try {
      const { occasion, items, style, products } = req.body;
      const ai = getGeminiClient();

      if (ai) {
        const productSummaries = Array.isArray(products)
          ? products.map((p: any) => `${p.id}: ${p.name} (${p.category}, $${p.price}) - ${p.tagline}. Capacity: ${p.capacityLiters}L`).join('\n')
          : '';

        const prompt = `You are the lead personal stylist and master leather goods consultant at "bag.Ze", a luxury handcrafted Italian leather goods house.
Customer Request:
- Occasion / Outfit Vibe: ${occasion || 'Everyday luxury'}
- Items to Carry: ${items || 'Laptop, daily essentials'}
- Style Aesthetic: ${style || 'Classic Luxury'}

Available bag.Ze Catalog:
${productSummaries}

Provide expert stylist recommendations tailored to this customer. Output your response strictly in valid JSON format:
{
  "recommendations": [
    {
      "productId": "id from catalog (e.g. bz-01)",
      "matchScore": 96,
      "whyItFits": "Two sentences explaining why this specific bag.Ze bag matches their outfit and daily carry requirements.",
      "outfitPairing": "Detailed outfit pairings (outerwear, footwear, color harmony) to elevate this look.",
      "stylistTip": "A mastercraft tip on wearing or preserving this bag for the occasion."
    }
  ],
  "stylistIntro": "A warm, high-fashion 1-2 sentence greeting from the bag.Ze Atelier."
}`;

        const geminiRes = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: prompt,
          config: {
            responseMimeType: 'application/json',
            temperature: 0.7,
          },
        });

        const rawText = geminiRes.text;
        if (rawText) {
          const parsed = JSON.parse(rawText);
          return res.json(parsed);
        }
      }

      // Fallback if no Gemini key or rate limited
      return res.json({
        stylistIntro: 'Welcome to the bag.Ze Atelier. Our personal stylist has curated these handcrafted selections based on your occasion.',
        recommendations: [
          {
            productId: (occasion && (occasion.toLowerCase().includes('trip') || occasion.toLowerCase().includes('travel'))) ? 'bz-02' : 'bz-01',
            matchScore: 97,
            whyItFits: `Specially balanced for "${occasion || 'your lifestyle'}", this piece delivers structured presence and effortlessly houses ${items || 'your daily tech'}.`,
            outfitPairing: 'Complement with a tailored camel trench coat, cashmere knitwear, and burnished leather Chelsea boots.',
            stylistTip: 'The vegetable-tanned Italian calfskin develops a deep, one-of-a-kind patina that looks even better with every journey.'
          },
          {
            productId: 'bz-03',
            matchScore: 92,
            whyItFits: 'Engineered for modern urban commute with dual ergonomic compartments and weatherproof Italian matte leather.',
            outfitPairing: 'Pair with an unstructured charcoal blazer, raw selvedge denim, and minimal leather trainers.',
            stylistTip: 'Utilize the hidden magnetic passport compartment for seamless transit security.'
          }
        ]
      });
    } catch (err: any) {
      console.error('Stylist API error:', err);
      res.status(500).json({ error: 'Failed to generate styling advice', details: err?.message });
    }
  });

  // AI Packing Planner Endpoint
  app.post('/api/ai/packing', async (req, res) => {
    try {
      const { bagName, capacityLiters, destination, tripDays, weather } = req.body;
      const ai = getGeminiClient();

      if (ai) {
        const prompt = `You are the master travel concierge at bag.Ze luxury leather goods.
A traveler is packing using their bag.Ze bag:
- Bag: ${bagName} (${capacityLiters} Liters)
- Destination: ${destination || 'Global City'}
- Duration: ${tripDays || 3} days
- Climate / Weather: ${weather || 'Mild'}

Provide an optimized travel packing plan in strict JSON:
{
  "estimatedVolumePercent": 82,
  "carryOnCompliant": true,
  "conciergeAdvice": "3 concise sentences on how to pack this specific bag.Ze bag efficiently.",
  "checklist": [
    { "name": "Item name", "category": "Clothing | Tech | Toiletries | Essentials", "packed": false }
  ]
}`;

        const geminiRes = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: prompt,
          config: {
            responseMimeType: 'application/json',
            temperature: 0.6,
          },
        });

        const rawText = geminiRes.text;
        if (rawText) {
          const parsed = JSON.parse(rawText);
          return res.json(parsed);
        }
      }

      // High-quality fallback packing plan
      const days = Number(tripDays) || 3;
      const vol = Math.min(95, Math.max(45, Math.round((days * 120) / (capacityLiters || 25) * 10)));
      return res.json({
        estimatedVolumePercent: vol,
        carryOnCompliant: (capacityLiters || 25) <= 45,
        conciergeAdvice: `For ${days} days in ${destination || 'your destination'}, roll knits tightly along the base of your ${bagName}. Place heavy footwear or grooming pouches first against the reinforced leather spine.`,
        checklist: [
          { name: `${days}x Breathable cotton / merino tops`, category: 'Clothing', packed: false },
          { name: `${Math.ceil(days / 2)}x Tailored trousers or dark denim`, category: 'Clothing', packed: false },
          { name: '1x Weather-appropriate outerwear layer', category: 'Clothing', packed: false },
          { name: `${days + 1}x Undergarments & socks`, category: 'Clothing', packed: false },
          { name: 'Laptop, charging brick & braided cables', category: 'Tech', packed: false },
          { name: 'Universal travel power adapter', category: 'Tech', packed: false },
          { name: 'Compact 100ml TSA grooming kit', category: 'Toiletries', packed: false },
          { name: 'Passport & bag.Ze travel wallet', category: 'Essentials', packed: false },
          { name: 'Polarized sunglasses in hard case', category: 'Essentials', packed: false },
        ]
      });
    } catch (err: any) {
      console.error('Packing API error:', err);
      res.status(500).json({ error: 'Failed to generate packing plan', details: err?.message });
    }
  });

  // Vite middleware in dev; static file serving in production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`bag.Ze server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
