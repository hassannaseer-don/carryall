/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect } from 'react';
import { PRODUCTS } from './data/products';
import { Product, ProductColor, CartItem, BagCategory } from './types';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { ProductCard } from './components/ProductCard';
import { QuickViewModal } from './components/QuickViewModal';
import { AiStylistModal } from './components/AiStylistModal';
import { AiPackingModal } from './components/AiPackingModal';
import { MonogramStudioModal } from './components/MonogramStudioModal';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { WishlistModal } from './components/WishlistModal';
import { FeaturesBanner } from './components/FeaturesBanner';
import { Footer } from './components/Footer';
import { Search, Sparkles, Filter, CheckCircle2 } from 'lucide-react';

export default function App() {
  const [products] = useState<Product[]>(PRODUCTS);
  const [selectedCategory, setSelectedCategory] = useState<BagCategory>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Local storage persisted state for cart and wishlist
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('bagze_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [wishlist, setWishlist] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem('bagze_wishlist');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Modals & Drawers state
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState<boolean>(false);
  const [isStylistOpen, setIsStylistOpen] = useState<boolean>(false);
  const [isPackingOpen, setIsPackingOpen] = useState<boolean>(false);
  const [isMonogramOpen, setIsMonogramOpen] = useState<boolean>(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState<boolean>(false);
  const [monogramTargetProduct, setMonogramTargetProduct] = useState<Product | null>(null);

  // Discount code
  const [discountCode, setDiscountCode] = useState<string>('');
  const [discountPercent, setDiscountPercent] = useState<number>(0);

  // Toast feedback state
  const [toast, setToast] = useState<{ id: number; message: string } | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem('bagze_cart', JSON.stringify(cart));
    } catch (e) {
      console.warn('Failed to save cart to localStorage', e);
    }
  }, [cart]);

  useEffect(() => {
    try {
      localStorage.setItem('bagze_wishlist', JSON.stringify(wishlist));
    } catch (e) {
      console.warn('Failed to save wishlist to localStorage', e);
    }
  }, [wishlist]);

  const showToast = (message: string) => {
    const id = Date.now();
    setToast({ id, message });
    setTimeout(() => {
      setToast((current) => (current?.id === id ? null : current));
    }, 3000);
  };

  // Add to cart handler
  const handleAddToCart = (
    product: Product,
    selectedColor: ProductColor,
    quantity: number = 1,
    monogram?: { initials: string; finish: 'gold' | 'silver' | 'blind' }
  ) => {
    const cartItemId = `${product.id}-${selectedColor.name}-${monogram ? monogram.initials + '-' + monogram.finish : 'plain'}`;
    
    setCart((prevCart) => {
      const existingIdx = prevCart.findIndex((i) => i.id === cartItemId);
      if (existingIdx > -1) {
        const updated = [...prevCart];
        updated[existingIdx].quantity += quantity;
        return updated;
      }
      return [
        ...prevCart,
        {
          id: cartItemId,
          product,
          selectedColor,
          quantity,
          monogram,
        },
      ];
    });

    showToast(`Added "${product.name}" (${selectedColor.name}) to your shopping bag!`);
  };

  // Quantity updates
  const handleUpdateQuantity = (cartItemId: string, delta: number) => {
    setCart((prevCart) => {
      return prevCart
        .map((item) => {
          if (item.id === cartItemId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[];
    });
  };

  const handleRemoveFromCart = (cartItemId: string) => {
    setCart((prev) => prev.filter((i) => i.id !== cartItemId));
    showToast('Item removed from shopping bag.');
  };

  // Wishlist toggle
  const handleToggleWishlist = (product: Product) => {
    setWishlist((prev) => {
      const exists = prev.some((p) => p.id === product.id);
      if (exists) {
        showToast(`Removed "${product.name}" from your wishlist.`);
        return prev.filter((p) => p.id !== product.id);
      } else {
        showToast(`Saved "${product.name}" to your wishlist!`);
        return [...prev, product];
      }
    });
  };

  // Discount code application
  const handleApplyDiscountCode = (code: string): boolean => {
    if (code.toUpperCase() === 'CARRY20') {
      setDiscountCode('CARRY20');
      setDiscountPercent(20);
      showToast('🎉 Promo code CARRY20 applied: 20% discount on entire order!');
      return true;
    }
    return false;
  };

  // Clear cart on completed order
  const handleOrderCompleted = () => {
    setCart([]);
  };

  // Scroll to products
  const handleExploreClick = () => {
    const el = document.getElementById('products-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Filtered products calculation
  const filteredProducts = useMemo(() => {
    return products.filter((product) => {
      const matchesCategory =
        selectedCategory === 'all' || product.category === selectedCategory;
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch =
        !q ||
        product.name.toLowerCase().includes(q) ||
        product.description.toLowerCase().includes(q) ||
        product.category.toLowerCase().includes(q) ||
        product.materials.toLowerCase().includes(q);

      return matchesCategory && matchesSearch;
    });
  }, [products, selectedCategory, searchQuery]);

  const cartTotal = useMemo(() => {
    return cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  }, [cart]);

  const cartCount = useMemo(() => {
    return cart.reduce((sum, item) => sum + item.quantity, 0);
  }, [cart]);

  return (
    <div className="min-h-screen bg-stone-50 text-stone-800 font-sans flex flex-col selection:bg-brand-700 selection:text-white">
      
      {/* Toast Notification */}
      {toast && (
        <div
          id="app-toast-notification"
          className="fixed bottom-6 right-6 z-50 bg-brand-950 text-white px-4 py-3 rounded-2xl shadow-2xl border border-amber-400/30 flex items-center gap-2.5 text-xs font-semibold animate-in slide-in-from-bottom-3 duration-200"
        >
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toast.message}</span>
        </div>
      )}

      {/* Navigation */}
      <Navbar
        currentCategory={selectedCategory}
        onSelectCategory={(cat) => {
          setSelectedCategory(cat);
          handleExploreClick();
        }}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        wishlistCount={wishlist.length}
        cartCount={cartCount}
        cartTotal={cartTotal}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenWishlist={() => setIsWishlistOpen(true)}
        onOpenStylist={() => setIsStylistOpen(true)}
        onOpenPacking={() => setIsPackingOpen(true)}
        onOpenMonogram={() => {
          setMonogramTargetProduct(null);
          setIsMonogramOpen(true);
        }}
      />

      {/* Hero Section */}
      <Hero
        onExploreClick={handleExploreClick}
        onOpenStylist={() => setIsStylistOpen(true)}
        onOpenPacking={() => setIsPackingOpen(true)}
        onSelectCategory={(cat) => {
          setSelectedCategory(cat);
          handleExploreClick();
        }}
      />

      {/* Main Curated Product Catalog Section */}
      <main id="products-section" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20 flex-1">
        
        {/* Header & Filter Controls */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-5">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-extrabold text-brand-700 uppercase tracking-widest">
                bag.Ze Atelier
              </span>
              <span className="text-stone-300">•</span>
              <span className="text-xs text-stone-500 font-medium">
                {filteredProducts.length} Handcrafted Pieces
              </span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl font-bold text-stone-900">
              Curated Leather Collection
            </h2>
          </div>

          {/* Filter Category Tabs */}
          <div className="flex flex-wrap items-center gap-2" id="filter-tabs-container">
            {(
              [
                { id: 'all', label: 'All Bags' },
                { id: 'Handbags', label: 'Handbags & Totes' },
                { id: 'Backpacks', label: 'Backpacks' },
                { id: 'Travel', label: 'Travel Duffles' },
                { id: 'Wallets', label: 'Wallets' },
              ] as { id: BagCategory; label: string }[]
            ).map((tab) => (
              <button
                key={tab.id}
                id={`filter-tab-${tab.id}`}
                onClick={() => setSelectedCategory(tab.id)}
                className={`px-4 py-2 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                  selectedCategory === tab.id
                    ? 'bg-brand-900 text-white shadow-sm ring-1 ring-brand-900'
                    : 'bg-white text-stone-600 hover:bg-stone-100 hover:text-stone-900 border border-stone-200'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Search Results Notice if filtered */}
        {searchQuery && (
          <div className="mb-6 p-3 bg-stone-100 rounded-xl text-xs text-stone-600 flex items-center justify-between">
            <span>
              Showing search results for "<strong className="text-stone-900">{searchQuery}</strong>" ({filteredProducts.length} results)
            </span>
            <button
              onClick={() => setSearchQuery('')}
              className="text-brand-700 font-bold hover:underline cursor-pointer"
            >
              Clear search
            </button>
          </div>
        )}

        {/* Products Grid */}
        {filteredProducts.length === 0 ? (
          <div className="text-center py-20 bg-white rounded-3xl border border-stone-200 p-8 shadow-xs">
            <div className="w-16 h-16 rounded-full bg-stone-100 flex items-center justify-center text-stone-400 mx-auto mb-4">
              <Filter className="w-8 h-8" />
            </div>
            <h3 className="font-serif text-xl font-bold text-stone-800">
              No bags match your criteria
            </h3>
            <p className="text-xs text-stone-500 mt-1 max-w-sm mx-auto">
              Try adjusting your category filter or search keywords to discover our handcrafted pieces.
            </p>
            <button
              onClick={() => {
                setSelectedCategory('all');
                setSearchQuery('');
              }}
              className="mt-5 px-6 py-2.5 bg-brand-900 text-white text-xs font-bold rounded-full hover:bg-brand-800 transition-colors cursor-pointer"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div
            id="product-grid"
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-6 sm:gap-8"
          >
            {filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                isWishlisted={wishlist.some((w) => w.id === product.id)}
                onToggleWishlist={handleToggleWishlist}
                onQuickView={setQuickViewProduct}
                onAddToCart={(prod, color) => handleAddToCart(prod, color, 1)}
                onMonogramCustomizer={(prod) => {
                  setMonogramTargetProduct(prod);
                  setIsMonogramOpen(true);
                }}
              />
            ))}
          </div>
        )}

        {/* AI Banner Callout in Catalog */}
        <div className="mt-16 p-8 bg-gradient-to-r from-brand-900 via-brand-800 to-stone-900 text-white rounded-3xl relative overflow-hidden shadow-xl border border-amber-300/20 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2 text-center md:text-left z-10">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-500/20 border border-amber-400/30 text-amber-300 text-xs font-bold uppercase rounded-full">
              <Sparkles className="w-3.5 h-3.5" />
              bag.Ze AI Concierge
            </span>
            <h3 className="font-serif text-2xl sm:text-3xl font-bold text-stone-100">
              Unsure which bag fits your lifestyle?
            </h3>
            <p className="text-xs sm:text-sm text-stone-300 max-w-lg font-light leading-relaxed">
              Our AI Personal Stylist analyzes your wardrobe palette, laptop size, and travel duration to recommend your ideal leather silhouette.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 z-10 shrink-0">
            <button
              onClick={() => setIsStylistOpen(true)}
              className="px-6 py-3 bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold rounded-full text-xs transition-all shadow-md cursor-pointer"
            >
              Consult AI Stylist
            </button>
            <button
              onClick={() => setIsPackingOpen(true)}
              className="px-6 py-3 bg-white/10 hover:bg-white/20 text-white font-bold rounded-full text-xs border border-white/20 transition-all cursor-pointer"
            >
              Plan Packing Volume
            </button>
          </div>
        </div>
      </main>

      {/* Brand Value Pillars & Testimonials */}
      <FeaturesBanner />

      {/* Footer */}
      <Footer
        onSelectCategory={(cat) => {
          setSelectedCategory(cat);
          handleExploreClick();
        }}
        onOpenStylist={() => setIsStylistOpen(true)}
        onOpenPacking={() => setIsPackingOpen(true)}
        onOpenMonogram={() => {
          setMonogramTargetProduct(null);
          setIsMonogramOpen(true);
        }}
      />

      {/* Modals & Slide-overs */}
      <QuickViewModal
        product={quickViewProduct}
        onClose={() => setQuickViewProduct(null)}
        onAddToCart={(prod, color, qty) => handleAddToCart(prod, color, qty)}
        onOpenMonogram={(prod) => {
          setMonogramTargetProduct(prod);
          setIsMonogramOpen(true);
        }}
      />

      <AiStylistModal
        isOpen={isStylistOpen}
        onClose={() => setIsStylistOpen(false)}
        products={products}
        onAddToCart={(prod, color) => handleAddToCart(prod, color, 1)}
        onQuickView={(prod) => {
          setIsStylistOpen(false);
          setQuickViewProduct(prod);
        }}
      />

      <AiPackingModal
        isOpen={isPackingOpen}
        onClose={() => setIsPackingOpen(false)}
        products={products}
        onOpenQuickView={(prod) => {
          setIsPackingOpen(false);
          setQuickViewProduct(prod);
        }}
      />

      <MonogramStudioModal
        isOpen={isMonogramOpen}
        onClose={() => setIsMonogramOpen(false)}
        products={products}
        initialProduct={monogramTargetProduct}
        onAddToCartWithMonogram={(prod, color, monogram) =>
          handleAddToCart(prod, color, 1, monogram)
        }
      />

      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveFromCart}
        onCheckout={() => {
          setIsCartOpen(false);
          setIsCheckoutOpen(true);
        }}
        discountCode={discountCode}
        onApplyDiscountCode={handleApplyDiscountCode}
        discountPercent={discountPercent}
      />

      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        items={cart}
        discountPercent={discountPercent}
        onOrderCompleted={handleOrderCompleted}
      />

      <WishlistModal
        isOpen={isWishlistOpen}
        onClose={() => setIsWishlistOpen(false)}
        wishlist={wishlist}
        onRemoveFromWishlist={handleToggleWishlist}
        onAddToCart={(prod, color) => handleAddToCart(prod, color, 1)}
        onQuickView={(prod) => {
          setIsWishlistOpen(false);
          setQuickViewProduct(prod);
        }}
      />

    </div>
  );
}
