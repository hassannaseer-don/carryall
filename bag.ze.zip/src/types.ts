export type BagCategory = 'all' | 'Handbags' | 'Backpacks' | 'Travel' | 'Wallets' | 'Crossbody';

export interface ProductColor {
  name: string;
  hex: string;
  image: string;
}

export interface Product {
  id: string;
  name: string;
  category: 'Handbags' | 'Backpacks' | 'Travel' | 'Wallets' | 'Crossbody';
  price: number;
  originalPrice?: number;
  rating: number;
  reviewCount: number;
  tagline: string;
  description: string;
  dimensions: string;
  capacityLiters: number;
  weight: string;
  materials: string;
  colors: ProductColor[];
  image: string;
  features: string[];
  careGuide: string;
  stylingAdvice: string;
  isBestSeller?: boolean;
  isNew?: boolean;
  canMonogram?: boolean;
}

export interface CartItem {
  id: string; // unique cart item id (e.g. product.id + color + monogram)
  product: Product;
  selectedColor: ProductColor;
  quantity: number;
  monogram?: {
    initials: string;
    finish: 'gold' | 'silver' | 'blind';
  };
}

export interface PackingItem {
  id: string;
  name: string;
  category: 'Clothing' | 'Tech' | 'Toiletries' | 'Essentials';
  packed: boolean;
}

export interface StylistRecommendation {
  productId: string;
  confidence: number;
  outfitPairing: string;
  reasoning: string;
  recommendedColor: string;
}
