import React from 'react';
import { Truck, Gem, Wand2, ShieldCheck, Star } from 'lucide-react';

export const FeaturesBanner: React.FC = () => {
  return (
    <>
      {/* Brand Value Pillars */}
      <section id="features-section" className="bg-brand-50/80 border-y border-brand-100/70 py-16 my-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 text-center">
            
            <div className="flex flex-col items-center">
              <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center text-brand-700 text-2xl shadow-xs mb-3.5 border border-brand-100">
                <Truck className="w-7 h-7" />
              </div>
              <h3 className="font-bold text-stone-900 text-sm">Complimentary Shipping</h3>
              <p className="text-xs text-stone-500 mt-1 max-w-xs leading-relaxed">
                Free standard worldwide express shipping on all handcrafted orders over $150.
              </p>
            </div>

            <div className="flex flex-col items-center">
              <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center text-brand-700 text-2xl shadow-xs mb-3.5 border border-brand-100">
                <Gem className="w-7 h-7" />
              </div>
              <h3 className="font-bold text-stone-900 text-sm">Full Grain Tuscan Leather</h3>
              <p className="text-xs text-stone-500 mt-1 max-w-xs leading-relaxed">
                Ethically sourced vegetable-tanned Italian hides built to age with an unmatched rich patina.
              </p>
            </div>

            <div className="flex flex-col items-center">
              <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center text-amber-700 text-2xl shadow-xs mb-3.5 border border-amber-200/60 bg-amber-50/50">
                <Wand2 className="w-7 h-7 text-amber-600" />
              </div>
              <h3 className="font-bold text-stone-900 text-sm">AI Stylist & Voice Audio Guide</h3>
              <p className="text-xs text-stone-500 mt-1 max-w-xs leading-relaxed">
                Curated outfit matching, spoken leather care audio, and smart luggage capacity planning.
              </p>
            </div>

            <div className="flex flex-col items-center">
              <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center text-brand-700 text-2xl shadow-xs mb-3.5 border border-brand-100">
                <ShieldCheck className="w-7 h-7" />
              </div>
              <h3 className="font-bold text-stone-900 text-sm">Lifetime Craft Guarantee</h3>
              <p className="text-xs text-stone-500 mt-1 max-w-xs leading-relaxed">
                We guarantee all structural stitching, brass hardware, and zippers against defects for life.
              </p>
            </div>

          </div>
        </div>
      </section>

      {/* Customer Testimonials */}
      <section id="testimonials-section" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="text-xs font-bold text-brand-700 uppercase tracking-widest">
            Verified Experiences
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl font-bold text-stone-900 mt-1">
            Loved by Modern Travelers & Executives
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-2xl shadow-xs border border-stone-200/80 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-1 text-amber-400 text-sm mb-3">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-amber-400" />
                ))}
              </div>
              <p className="text-stone-600 text-xs sm:text-sm leading-relaxed italic">
                "The Sovereign Tote is hands down the best work bag I have ever owned. Fits my 16" laptop effortlessly and still looks amazingly sleek during high-stakes boardroom presentations."
              </p>
            </div>
            <div className="mt-6 flex items-center gap-3 pt-4 border-t border-stone-100">
              <img
                src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150"
                alt="Sarah Jenkins"
                className="w-10 h-10 rounded-full object-cover ring-2 ring-brand-100"
              />
              <div>
                <h3 className="font-bold text-xs text-stone-900">Sarah Jenkins</h3>
                <span className="text-[10px] text-stone-400">Verified Buyer • Sovereign Tote</span>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-2xl shadow-xs border border-stone-200/80 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-1 text-amber-400 text-sm mb-3">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-amber-400" />
                ))}
              </div>
              <p className="text-stone-600 text-xs sm:text-sm leading-relaxed italic">
                "The leather quality on the Voyager Duffle is unmatched. Smells incredible and has acquired a gorgeous vintage patina after trips to Zurich and Kyoto. The custom gold monogram is exquisite."
              </p>
            </div>
            <div className="mt-6 flex items-center gap-3 pt-4 border-t border-stone-100">
              <img
                src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=150"
                alt="Marcus Vance"
                className="w-10 h-10 rounded-full object-cover ring-2 ring-brand-100"
              />
              <div>
                <h3 className="font-bold text-xs text-stone-900">Marcus Vance</h3>
                <span className="text-[10px] text-stone-400">Verified Buyer • Voyager Duffle</span>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-2xl shadow-xs border border-stone-200/80 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-1 text-amber-400 text-sm mb-3">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-amber-400" />
                ))}
              </div>
              <p className="text-stone-600 text-xs sm:text-sm leading-relaxed italic">
                "The AI Packing Planner organized my 5-day flight into the Urban Executive Backpack flawlessly! I also love listening to the spoken voice leather care guide right from my phone."
              </p>
            </div>
            <div className="mt-6 flex items-center gap-3 pt-4 border-t border-stone-100">
              <img
                src="https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&q=80&w=150"
                alt="Elena Rostova"
                className="w-10 h-10 rounded-full object-cover ring-2 ring-brand-100"
              />
              <div>
                <h3 className="font-bold text-xs text-stone-900">Elena Rostova</h3>
                <span className="text-[10px] text-stone-400">Verified Buyer • Urban Backpack</span>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};
