import React from 'react';
import { ShoppingBag, Heart, Search, Menu, X, Sparkles, Compass, Stamp, ArrowRight } from 'lucide-react';
import { BagCategory } from '../types';

interface NavbarProps {
  currentCategory: BagCategory;
  onSelectCategory: (cat: BagCategory) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  wishlistCount: number;
  cartCount: number;
  cartTotal: number;
  onOpenCart: () => void;
  onOpenWishlist: () => void;
  onOpenStylist: () => void;
  onOpenPacking: () => void;
  onOpenMonogram: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentCategory,
  onSelectCategory,
  searchQuery,
  onSearchChange,
  wishlistCount,
  cartCount,
  cartTotal,
  onOpenCart,
  onOpenWishlist,
  onOpenStylist,
  onOpenPacking,
  onOpenMonogram,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  const categories: { id: BagCategory; label: string }[] = [
    { id: 'all', label: 'All Bags' },
    { id: 'Handbags', label: 'Handbags & Totes' },
    { id: 'Backpacks', label: 'Backpacks' },
    { id: 'Travel', label: 'Travel Duffles' },
    { id: 'Wallets', label: 'Wallets & Folios' },
  ];

  return (
    <>
      {/* Top Announcement Bar */}
      <div id="announcement-bar" className="bg-brand-900 text-stone-200 text-xs py-2 px-4 text-center tracking-wide font-medium flex items-center justify-center flex-wrap gap-3 border-b border-brand-800">
        <div className="flex items-center gap-1.5">
          <span className="inline-block w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping"></span>
          <span>Spring Exclusive: Enjoy 20% OFF with code <strong className="text-amber-300 font-mono tracking-wider bg-brand-800/80 px-1.5 py-0.5 rounded">CARRY20</strong></span>
        </div>
        <div className="hidden sm:flex items-center gap-2">
          <button
            id="top-ai-stylist-btn"
            onClick={onOpenStylist}
            className="inline-flex items-center gap-1 bg-amber-500/20 hover:bg-amber-500/40 text-amber-200 text-[11px] px-2.5 py-0.5 rounded-full border border-amber-400/30 transition-all font-semibold cursor-pointer"
          >
            <Sparkles className="w-3 h-3 text-amber-300" />
            <span>AI Stylist</span>
          </button>
          <button
            id="top-ai-packing-btn"
            onClick={onOpenPacking}
            className="inline-flex items-center gap-1 bg-brand-800 hover:bg-brand-700 text-stone-200 text-[11px] px-2.5 py-0.5 rounded-full border border-brand-700 transition-all font-semibold cursor-pointer"
          >
            <Compass className="w-3 h-3 text-brand-300" />
            <span>Packing Planner</span>
          </button>
          <button
            id="top-monogram-btn"
            onClick={onOpenMonogram}
            className="inline-flex items-center gap-1 bg-amber-500/10 hover:bg-amber-500/30 text-amber-100 text-[11px] px-2.5 py-0.5 rounded-full border border-amber-400/20 transition-all font-semibold cursor-pointer"
          >
            <Stamp className="w-3 h-3 text-amber-300" />
            <span>Custom Monogram</span>
          </button>
        </div>
      </div>

      {/* Main Navigation Header */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-stone-200/80 transition-all shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            
            {/* Mobile Menu Toggle Button */}
            <button
              id="mobile-menu-toggle-btn"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-stone-700 hover:text-brand-900 rounded-lg hover:bg-stone-100 transition-colors focus:outline-none"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>

            {/* Brand Logo - bag.Ze */}
            <div className="flex-shrink-0 flex items-center gap-2.5">
              <a href="#" className="flex items-center gap-2.5 group">
                <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-brand-900 via-brand-800 to-brand-700 text-amber-200 flex items-center justify-center font-serif text-lg font-bold shadow-md ring-1 ring-amber-300/30 group-hover:scale-105 transition-transform">
                  <span>bZ</span>
                </div>
                <div className="flex flex-col">
                  <span className="font-serif text-2xl sm:text-3xl font-extrabold tracking-tight text-brand-900 flex items-center">
                    bag<span className="text-amber-600">.Ze</span>
                  </span>
                  <span className="text-[9px] tracking-[0.25em] text-brand-700 uppercase -mt-1 font-semibold">Atelier Leather</span>
                </div>
              </a>
            </div>

            {/* Desktop Navigation Links */}
            <nav className="hidden lg:flex items-center gap-6 font-medium text-sm text-stone-600">
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  id={`nav-cat-${cat.id}`}
                  onClick={() => onSelectCategory(cat.id)}
                  className={`transition-colors py-1 cursor-pointer relative ${
                    currentCategory === cat.id
                      ? 'text-brand-900 font-bold'
                      : 'text-stone-600 hover:text-brand-900'
                  }`}
                >
                  {cat.label}
                  {currentCategory === cat.id && (
                    <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-brand-700 rounded-full"></span>
                  )}
                </button>
              ))}

              <div className="h-4 w-[1px] bg-stone-200"></div>

              {/* AI Feature Buttons in Nav */}
              <button
                id="nav-ai-stylist-btn"
                onClick={onOpenStylist}
                className="flex items-center gap-1.5 px-3.5 py-1.5 bg-amber-50/80 hover:bg-amber-100 text-amber-900 border border-amber-300/70 rounded-full text-xs font-bold transition-all shadow-xs cursor-pointer hover:border-amber-400"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                <span>AI Stylist</span>
              </button>

              <button
                id="nav-ai-packing-btn"
                onClick={onOpenPacking}
                className="flex items-center gap-1.5 px-3.5 py-1.5 bg-brand-50 hover:bg-brand-100 text-brand-900 border border-brand-200/80 rounded-full text-xs font-bold transition-all shadow-xs cursor-pointer"
              >
                <Compass className="w-3.5 h-3.5 text-brand-700" />
                <span>AI Packing</span>
              </button>

              <button
                id="nav-monogram-studio-btn"
                onClick={onOpenMonogram}
                className="flex items-center gap-1.5 px-3.5 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-800 border border-stone-300/60 rounded-full text-xs font-bold transition-all shadow-xs cursor-pointer"
              >
                <Stamp className="w-3.5 h-3.5 text-stone-600" />
                <span>Monogram</span>
              </button>
            </nav>

            {/* Right Action Icons */}
            <div className="flex items-center gap-2.5 sm:gap-3.5">
              {/* Search Input */}
              <div className="relative hidden sm:block w-36 md:w-48 lg:w-56">
                <input
                  id="navbar-search-input"
                  type="text"
                  value={searchQuery}
                  onChange={(e) => onSearchChange(e.target.value)}
                  placeholder="Search bags, duffles..."
                  className="w-full pl-9 pr-4 py-2 bg-stone-100/90 border border-transparent rounded-full text-xs text-stone-800 placeholder-stone-400 focus:outline-none focus:bg-white focus:border-brand-500 transition-all"
                />
                <Search className="w-3.5 h-3.5 absolute left-3 top-3 text-stone-400" />
                {searchQuery && (
                  <button
                    onClick={() => onSearchChange('')}
                    className="absolute right-2.5 top-2.5 text-stone-400 hover:text-stone-700 text-xs"
                    title="Clear search"
                  >
                    ×
                  </button>
                )}
              </div>

              {/* Favorites Wishlist Icon */}
              <button
                id="navbar-wishlist-btn"
                onClick={onOpenWishlist}
                className="relative p-2.5 text-stone-700 hover:text-brand-900 rounded-full hover:bg-stone-100 transition-colors cursor-pointer"
                title="View Saved Bags"
              >
                <Heart className="w-5 h-5" />
                {wishlistCount > 0 && (
                  <span className="absolute top-1 right-1 w-4 h-4 bg-amber-600 text-white text-[10px] font-bold rounded-full flex items-center justify-center ring-2 ring-white">
                    {wishlistCount}
                  </span>
                )}
              </button>

              {/* Shopping Bag / Cart Trigger Button */}
              <button
                id="navbar-cart-btn"
                onClick={onOpenCart}
                className="relative p-2 sm:px-3 sm:py-2 bg-brand-900 hover:bg-brand-800 text-white rounded-full flex items-center gap-2 transition-all shadow-sm cursor-pointer"
                title="View Shopping Bag"
              >
                <div className="relative flex items-center">
                  <ShoppingBag className="w-4 h-4 text-amber-200" />
                  {cartCount > 0 && (
                    <span className="ml-1.5 bg-amber-500 text-stone-950 text-[10px] font-extrabold px-1.5 py-0.2 rounded-full">
                      {cartCount}
                    </span>
                  )}
                </div>
                <span className="hidden md:inline font-semibold text-xs text-stone-100 font-mono">
                  ${cartTotal.toFixed(2)}
                </span>
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu Dropdown */}
        {mobileMenuOpen && (
          <div id="mobile-menu-drawer" className="lg:hidden border-t border-stone-200 bg-white px-5 py-5 space-y-4 shadow-xl animate-in slide-in-from-top-2 duration-200">
            {/* Mobile Search */}
            <div className="relative">
              <input
                id="mobile-search-input"
                type="text"
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                placeholder="Search leather goods..."
                className="w-full pl-9 pr-4 py-2.5 bg-stone-100 border border-stone-200 rounded-xl text-xs text-stone-800 placeholder-stone-400 focus:outline-none focus:bg-white focus:border-brand-500"
              />
              <Search className="w-4 h-4 absolute left-3 top-3 text-stone-400" />
            </div>

            <div className="space-y-1 pt-1">
              <span className="text-[11px] font-bold uppercase tracking-wider text-stone-400 px-1">Collections</span>
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => {
                    onSelectCategory(cat.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full text-left py-2.5 px-3 rounded-xl text-sm font-medium flex items-center justify-between transition-colors ${
                    currentCategory === cat.id
                      ? 'bg-brand-50 text-brand-900 font-bold'
                      : 'text-stone-700 hover:bg-stone-50'
                  }`}
                >
                  <span>{cat.label}</span>
                  <ArrowRight className="w-3.5 h-3.5 opacity-40" />
                </button>
              ))}
            </div>

            <div className="pt-3 border-t border-stone-100 space-y-2">
              <span className="text-[11px] font-bold uppercase tracking-wider text-amber-700 px-1">✨ AI & Custom Services</span>
              <button
                onClick={() => {
                  onOpenStylist();
                  setMobileMenuOpen(false);
                }}
                className="w-full text-left py-2.5 px-3.5 bg-amber-50 hover:bg-amber-100 text-amber-950 rounded-xl text-xs font-bold flex items-center gap-2 transition-all border border-amber-200/60"
              >
                <Sparkles className="w-4 h-4 text-amber-600" />
                <span>✨ AI Personal Bag Stylist</span>
              </button>

              <button
                onClick={() => {
                  onOpenPacking();
                  setMobileMenuOpen(false);
                }}
                className="w-full text-left py-2.5 px-3.5 bg-brand-50 hover:bg-brand-100 text-brand-900 rounded-xl text-xs font-bold flex items-center gap-2 transition-all border border-brand-200/60"
              >
                <Compass className="w-4 h-4 text-brand-700" />
                <span>✨ AI Bag Packing Planner</span>
              </button>

              <button
                onClick={() => {
                  onOpenMonogram();
                  setMobileMenuOpen(false);
                }}
                className="w-full text-left py-2.5 px-3.5 bg-stone-100 hover:bg-stone-200 text-stone-900 rounded-xl text-xs font-bold flex items-center gap-2 transition-all border border-stone-200"
              >
                <Stamp className="w-4 h-4 text-stone-600" />
                <span>✨ Monogram & Gift Studio</span>
              </button>
            </div>
          </div>
        )}
      </header>
    </>
  );
};
