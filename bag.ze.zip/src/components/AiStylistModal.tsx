import React, { useState } from 'react';
import { X, Sparkles, Loader2, ShoppingBag, ArrowRight, Check, Eye } from 'lucide-react';
import { Product, ProductColor } from '../types';

interface AiStylistModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  onAddToCart: (product: Product, color: ProductColor) => void;
  onQuickView: (product: Product) => void;
}

interface StylistResponse {
  stylistIntro?: string;
  recommendations: Array<{
    productId: string;
    matchScore: number;
    whyItFits: string;
    outfitPairing: string;
    stylistTip: string;
  }>;
}

export const AiStylistModal: React.FC<AiStylistModalProps> = ({
  isOpen,
  onClose,
  products,
  onAddToCart,
  onQuickView,
}) => {
  if (!isOpen) return null;

  const [occasion, setOccasion] = useState('3-day business trip to Paris, beige trench coat, meeting executives');
  const [items, setItems] = useState('15" laptop, passport, leather notebook, sunglasses');
  const [style, setStyle] = useState('Classic Luxury & Leather');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<StylistResponse | null>(null);
  const [addedItemMap, setAddedItemMap] = useState<Record<string, boolean>>({});

  const handleConsultStylist = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const res = await fetch('/api/ai/stylist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          occasion,
          items,
          style,
          products: products.map((p) => ({
            id: p.id,
            name: p.name,
            category: p.category,
            price: p.price,
            tagline: p.tagline,
            capacityLiters: p.capacityLiters,
          })),
        }),
      });

      if (!res.ok) throw new Error('API request failed');
      const data = await res.json();
      setResult(data);
    } catch (err) {
      console.error(err);
      // Fallback response if network or server error
      setResult({
        stylistIntro: 'Our bag.Ze Atelier stylists have evaluated your outfit and travel needs to recommend these prime matches.',
        recommendations: [
          {
            productId: 'bz-02',
            matchScore: 98,
            whyItFits: `The Voyager Weekender Duffle effortlessly accommodates your luggage and ${items}, while perfectly complementing your travel schedule.`,
            outfitPairing: 'Wear with your beige trench coat, slim dark trousers, and cognac leather footwear for timeless continental poise.',
            stylistTip: 'The Tuscan leather will develop a rich caramel patina across your travels.',
          },
          {
            productId: 'bz-01',
            matchScore: 94,
            whyItFits: 'The Sovereign Tote provides dedicated 16" padded laptop security with structured silhouette that stays upright during executive meetings.',
            outfitPairing: 'Pair with tailored blazers, silk scarves, and subtle gold jewelry.',
            stylistTip: 'Features protective brass feet so you can place it on marble or conference floors safely.',
          },
        ],
      });
    } finally {
      setLoading(false);
    }
  };

  const handleAdd = (product: Product) => {
    onAddToCart(product, product.colors[0]);
    setAddedItemMap((prev) => ({ ...prev, [product.id]: true }));
    setTimeout(() => {
      setAddedItemMap((prev) => ({ ...prev, [product.id]: false }));
    }, 1500);
  };

  return (
    <div
      id="ai-stylist-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-stone-950/70 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        id="ai-stylist-modal-content"
        className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl relative my-auto border border-amber-200/60 max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close button */}
        <button
          id="close-ai-stylist-btn"
          onClick={onClose}
          className="absolute top-5 right-5 text-stone-400 hover:text-stone-700 p-1.5 rounded-full hover:bg-stone-100 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3.5 mb-5">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-600 via-amber-700 to-amber-900 text-amber-200 flex items-center justify-center text-xl shadow-md ring-1 ring-amber-400/30 shrink-0">
            <Sparkles className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[10px] font-extrabold uppercase tracking-widest text-amber-700 bg-amber-100/70 px-2 py-0.5 rounded-sm">
              bag.Ze Atelier AI
            </span>
            <h2 className="font-serif text-2xl font-bold text-stone-900 mt-0.5">
              Personal Bag Stylist & Outfit Matcher
            </h2>
            <p className="text-xs text-stone-500">
              Tell us your itinerary, outfit vibe, or what you are carrying for tailor-made recommendations.
            </p>
          </div>
        </div>

        {/* Input Form */}
        <form onSubmit={handleConsultStylist} className="space-y-4 my-4">
          <div>
            <label className="block text-xs font-bold text-stone-800 mb-1">
              Occasion / Outfit Vibe
            </label>
            <input
              id="stylist-occasion-input"
              type="text"
              value={occasion}
              onChange={(e) => setOccasion(e.target.value)}
              placeholder="e.g. 3-day business trip to Paris with beige trench coat, or weekend art gallery tour"
              className="w-full px-4 py-2.5 rounded-xl bg-stone-50 border border-stone-200 text-xs focus:bg-white focus:border-brand-500 focus:outline-none transition-all text-stone-800"
              required
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="block text-xs font-bold text-stone-800 mb-1">
                Items to Carry
              </label>
              <input
                id="stylist-items-input"
                type="text"
                value={items}
                onChange={(e) => setItems(e.target.value)}
                placeholder="e.g. 15-inch laptop, passport, books, sunglasses"
                className="w-full px-4 py-2.5 rounded-xl bg-stone-50 border border-stone-200 text-xs focus:bg-white focus:border-brand-500 focus:outline-none transition-all text-stone-800"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-800 mb-1">
                Style Preference
              </label>
              <select
                id="stylist-style-select"
                value={style}
                onChange={(e) => setStyle(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl bg-stone-50 border border-stone-200 text-xs focus:bg-white focus:border-brand-500 focus:outline-none transition-all text-stone-800 cursor-pointer"
              >
                <option value="Classic Luxury & Leather">Classic Luxury & Vegetable Leather</option>
                <option value="Modern Minimalist">Modern Minimalist Executive</option>
                <option value="Travel & Functional Utility">Travel & Functional Utility</option>
                <option value="Casual Chic & Crossbody">Casual Chic & Evening</option>
              </select>
            </div>
          </div>

          <button
            id="submit-ai-stylist-btn"
            type="submit"
            disabled={loading}
            className="w-full py-3 px-4 bg-gradient-to-r from-amber-700 via-amber-800 to-amber-900 hover:from-amber-600 hover:to-amber-800 active:scale-99 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer disabled:opacity-75"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin text-amber-200" />
                <span>Consulting bag.Ze Atelier AI Stylist...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>Get Curated Bag & Outfit Recommendations</span>
              </>
            )}
          </button>
        </form>

        {/* AI Recommendations Output */}
        {result && (
          <div className="mt-6 pt-5 border-t border-stone-200 space-y-4 animate-in fade-in duration-300">
            {result.stylistIntro && (
              <p className="text-xs text-stone-600 italic bg-amber-50/70 p-3 rounded-xl border border-amber-200/60 leading-relaxed">
                "{result.stylistIntro}"
              </p>
            )}

            <div className="space-y-4">
              {result.recommendations.map((rec) => {
                const matchedProduct = products.find((p) => p.id === rec.productId) || products[0];
                const isAdded = addedItemMap[matchedProduct.id];

                return (
                  <div
                    key={rec.productId}
                    className="p-4 rounded-2xl border border-stone-200 bg-stone-50/60 hover:bg-stone-50 transition-colors flex flex-col sm:flex-row gap-4 items-start"
                  >
                    <img
                      src={matchedProduct.image}
                      alt={matchedProduct.name}
                      className="w-20 h-20 rounded-xl object-cover shrink-0 border border-stone-200"
                    />

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <h4 className="font-serif font-bold text-stone-900 text-sm">
                          {matchedProduct.name}
                        </h4>
                        <span className="text-[11px] font-bold text-emerald-700 bg-emerald-100/80 px-2 py-0.5 rounded-full font-mono">
                          {rec.matchScore}% Match
                        </span>
                      </div>

                      <p className="text-xs font-mono font-bold text-stone-800 mt-0.5">
                        ${matchedProduct.price} • {matchedProduct.capacityLiters}L Capacity
                      </p>

                      <p className="text-xs text-stone-700 mt-2 leading-relaxed">
                        <strong className="text-amber-900">Why It Fits:</strong> {rec.whyItFits}
                      </p>

                      <p className="text-xs text-stone-600 mt-1.5 leading-relaxed bg-white p-2.5 rounded-lg border border-stone-200/60">
                        <strong className="text-stone-800">Outfit Pairing:</strong> {rec.outfitPairing}
                      </p>

                      <div className="flex items-center gap-2 mt-3">
                        <button
                          onClick={() => handleAdd(matchedProduct)}
                          className={`px-3.5 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                            isAdded
                              ? 'bg-emerald-600 text-white'
                              : 'bg-brand-900 hover:bg-brand-800 text-white'
                          }`}
                        >
                          {isAdded ? (
                            <>
                              <Check className="w-3.5 h-3.5" />
                              <span>Added to Bag</span>
                            </>
                          ) : (
                            <>
                              <ShoppingBag className="w-3.5 h-3.5 text-amber-300" />
                              <span>Add to Bag</span>
                            </>
                          )}
                        </button>

                        <button
                          onClick={() => {
                            onClose();
                            onQuickView(matchedProduct);
                          }}
                          className="px-3 py-1.5 rounded-lg text-xs font-semibold text-stone-700 hover:text-stone-900 bg-white border border-stone-200 hover:bg-stone-100 flex items-center gap-1 cursor-pointer"
                        >
                          <Eye className="w-3.5 h-3.5 text-stone-500" />
                          <span>View Details</span>
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
