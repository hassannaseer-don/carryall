import React from 'react';
import { Sparkles, Compass, ArrowRight, Briefcase, ShoppingBag, Plane, Wallet, ShieldCheck, Award } from 'lucide-react';
import { BagCategory } from '../types';

interface HeroProps {
  onExploreClick: () => void;
  onOpenStylist: () => void;
  onOpenPacking: () => void;
  onSelectCategory: (category: BagCategory) => void;
}

export const Hero: React.FC<HeroProps> = ({
  onExploreClick,
  onOpenStylist,
  onOpenPacking,
  onSelectCategory,
}) => {
  return (
    <div className="relative">
      {/* Hero Banner with Luxury Background Image */}
      <section id="hero-section" className="relative bg-stone-950 text-white overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&q=80&w=1920"
            alt="bag.Ze handcrafted luxury Italian leather bags"
            className="w-full h-full object-cover object-center opacity-35 filter brightness-90"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-stone-950 via-stone-950/75 to-transparent"></div>
          <div className="absolute inset-0 bg-radial from-transparent via-transparent to-stone-950/80"></div>
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 sm:py-28 lg:py-32 flex flex-col justify-center min-h-[560px]">
          
          <div className="flex items-center gap-2 mb-4">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-500/20 backdrop-blur-md border border-amber-400/30 text-amber-300 text-xs tracking-widest font-semibold uppercase rounded-full">
              <Award className="w-3.5 h-3.5 text-amber-400" />
              Handcrafted Italian Leather
            </span>
            <span className="hidden sm:inline-flex items-center gap-1 px-3 py-1 bg-white/10 text-stone-300 text-xs rounded-full border border-white/15">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              Lifetime Stitching Guarantee
            </span>
          </div>

          <h1 className="font-serif text-4xl sm:text-6xl lg:text-7xl font-bold tracking-tight text-stone-100 max-w-3xl leading-[1.08]">
            Elegance You Carry. <br />
            <span className="text-amber-200/90 italic font-medium">Crafted by bag.Ze</span>
          </h1>

          <p className="mt-5 text-base sm:text-lg text-stone-300 max-w-xl font-light leading-relaxed">
            Discover our collection of ethically sourced, vegetable-tanned Tuscan leather bags — engineered with precision for effortless journeys and timeless daily sophistication.
          </p>

          <div className="mt-8 flex flex-wrap items-center gap-3.5">
            <button
              id="hero-explore-btn"
              onClick={onExploreClick}
              className="px-7 py-3.5 bg-brand-500 hover:bg-brand-600 active:scale-95 text-white font-semibold rounded-full shadow-lg hover:shadow-brand-500/20 transition-all duration-200 text-sm flex items-center gap-2 cursor-pointer"
            >
              <span>Explore Collection</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            {/* AI Assistant Triggers */}
            <button
              id="hero-stylist-btn"
              onClick={onOpenStylist}
              className="px-6 py-3.5 bg-gradient-to-r from-amber-700 via-amber-800 to-amber-900 hover:from-amber-600 hover:to-amber-800 text-white font-semibold rounded-full shadow-lg border border-amber-400/30 transition-all duration-200 text-sm flex items-center gap-2 cursor-pointer group"
            >
              <Sparkles className="w-4 h-4 text-amber-300 group-hover:rotate-12 transition-transform" />
              <span>Match Outfit with AI</span>
            </button>

            <button
              id="hero-packing-btn"
              onClick={onOpenPacking}
              className="px-6 py-3.5 bg-white/10 hover:bg-white/20 active:scale-95 backdrop-blur-md text-white font-semibold rounded-full border border-white/20 transition-all duration-200 text-sm flex items-center gap-2 cursor-pointer"
            >
              <Compass className="w-4 h-4 text-amber-200" />
              <span>AI Packing Planner</span>
            </button>
          </div>
        </div>
      </section>

      {/* Quick Category Feature Cards */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-9 relative z-20">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5 sm:gap-4">
          
          <button
            id="quick-card-handbags"
            onClick={() => onSelectCategory('Handbags')}
            className="cursor-pointer group text-left bg-white p-4 sm:p-5 rounded-2xl shadow-sm hover:shadow-md border border-stone-200/80 transition-all flex items-center gap-3.5 hover:border-brand-300"
          >
            <div className="w-11 h-11 rounded-xl bg-brand-50 text-brand-700 flex items-center justify-center text-lg group-hover:bg-brand-500 group-hover:text-white transition-colors shrink-0">
              <ShoppingBag className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-stone-800 text-sm group-hover:text-brand-700 transition-colors">Handbags & Totes</h2>
              <p className="text-[11px] text-stone-400">Structured leather</p>
            </div>
          </button>

          <button
            id="quick-card-backpacks"
            onClick={() => onSelectCategory('Backpacks')}
            className="cursor-pointer group text-left bg-white p-4 sm:p-5 rounded-2xl shadow-sm hover:shadow-md border border-stone-200/80 transition-all flex items-center gap-3.5 hover:border-brand-300"
          >
            <div className="w-11 h-11 rounded-xl bg-brand-50 text-brand-700 flex items-center justify-center text-lg group-hover:bg-brand-500 group-hover:text-white transition-colors shrink-0">
              <Briefcase className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-stone-800 text-sm group-hover:text-brand-700 transition-colors">Backpacks</h2>
              <p className="text-[11px] text-stone-400">Laptop & commute</p>
            </div>
          </button>

          <button
            id="quick-card-travel"
            onClick={() => onSelectCategory('Travel')}
            className="cursor-pointer group text-left bg-white p-4 sm:p-5 rounded-2xl shadow-sm hover:shadow-md border border-stone-200/80 transition-all flex items-center gap-3.5 hover:border-brand-300"
          >
            <div className="w-11 h-11 rounded-xl bg-brand-50 text-brand-700 flex items-center justify-center text-lg group-hover:bg-brand-500 group-hover:text-white transition-colors shrink-0">
              <Plane className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-stone-800 text-sm group-hover:text-brand-700 transition-colors">Travel Duffles</h2>
              <p className="text-[11px] text-stone-400">Weekender & flights</p>
            </div>
          </button>

          <button
            id="quick-card-wallets"
            onClick={() => onSelectCategory('Wallets')}
            className="cursor-pointer group text-left bg-white p-4 sm:p-5 rounded-2xl shadow-sm hover:shadow-md border border-stone-200/80 transition-all flex items-center gap-3.5 hover:border-brand-300"
          >
            <div className="w-11 h-11 rounded-xl bg-brand-50 text-brand-700 flex items-center justify-center text-lg group-hover:bg-brand-500 group-hover:text-white transition-colors shrink-0">
              <Wallet className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-stone-800 text-sm group-hover:text-brand-700 transition-colors">Wallets & Folios</h2>
              <p className="text-[11px] text-stone-400">Slim RFID leather</p>
            </div>
          </button>

        </div>
      </section>
    </div>
  );
};
