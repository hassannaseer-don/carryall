import React from 'react';
import { Sparkles, Compass, Stamp, ArrowUpRight } from 'lucide-react';
import { BagCategory } from '../types';

interface FooterProps {
  onSelectCategory: (category: BagCategory) => void;
  onOpenStylist: () => void;
  onOpenPacking: () => void;
  onOpenMonogram: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onSelectCategory,
  onOpenStylist,
  onOpenPacking,
  onOpenMonogram,
}) => {
  return (
    <footer id="footer-section" className="bg-stone-950 text-stone-300 pt-16 pb-12 border-t border-stone-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10 pb-12 border-b border-stone-800">
          
          {/* Brand Info */}
          <div className="space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-full bg-brand-900 text-amber-200 flex items-center justify-center font-serif text-lg font-bold ring-1 ring-amber-400/30">
                bZ
              </div>
              <span className="font-serif text-2xl font-bold tracking-tight text-stone-100">
                bag<span className="text-amber-500">.Ze</span>
              </span>
            </div>
            <p className="text-xs text-stone-400 leading-relaxed">
              Purveyors of handcrafted Italian leather bags, duffles, and accessories. Designed in Florence, Italy, for modern globetrotters and discerning professionals.
            </p>
            <div className="flex items-center gap-2 text-xs text-amber-300/80 font-medium">
              <span>Florence • London • Tokyo • New York</span>
            </div>
          </div>

          {/* Collections */}
          <div>
            <h4 className="font-serif text-sm font-bold text-stone-100 tracking-wider uppercase mb-4">
              Collections
            </h4>
            <ul className="space-y-2.5 text-xs text-stone-400">
              <li>
                <button
                  onClick={() => onSelectCategory('Handbags')}
                  className="hover:text-amber-300 transition-colors cursor-pointer"
                >
                  Handbags & Classic Totes
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectCategory('Backpacks')}
                  className="hover:text-amber-300 transition-colors cursor-pointer"
                >
                  Executive Laptop Backpacks
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectCategory('Travel')}
                  className="hover:text-amber-300 transition-colors cursor-pointer"
                >
                  Voyager Weekenders & Travel
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectCategory('Wallets')}
                  className="hover:text-amber-300 transition-colors cursor-pointer"
                >
                  RFID Wallets & Travel Folios
                </button>
              </li>
            </ul>
          </div>

          {/* AI Atelier Services */}
          <div>
            <h4 className="font-serif text-sm font-bold text-stone-100 tracking-wider uppercase mb-4">
              Atelier Services
            </h4>
            <ul className="space-y-2.5 text-xs text-stone-400">
              <li>
                <button
                  onClick={onOpenStylist}
                  className="hover:text-amber-300 transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  <span>AI Personal Bag Stylist</span>
                </button>
              </li>
              <li>
                <button
                  onClick={onOpenPacking}
                  className="hover:text-amber-300 transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <Compass className="w-3.5 h-3.5 text-brand-400" />
                  <span>AI Luggage Packing Planner</span>
                </button>
              </li>
              <li>
                <button
                  onClick={onOpenMonogram}
                  className="hover:text-amber-300 transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <Stamp className="w-3.5 h-3.5 text-amber-300" />
                  <span>Custom Gold Monogramming</span>
                </button>
              </li>
              <li className="text-stone-500">Bespoke Leather Restoration</li>
            </ul>
          </div>

          {/* Newsletter / Spring Code */}
          <div className="space-y-3">
            <h4 className="font-serif text-sm font-bold text-stone-100 tracking-wider uppercase mb-2">
              The bag.Ze Journal
            </h4>
            <p className="text-xs text-stone-400">
              Receive private invitations to limited-edition leather drops and bespoke atelier releases.
            </p>
            <div className="p-3 bg-stone-900 rounded-xl border border-stone-800 text-xs">
              <span className="text-amber-300 font-bold block mb-1">Spring Atelier Code</span>
              <span className="text-stone-300">
                Use code <code className="font-mono bg-stone-800 px-1.5 py-0.5 rounded text-amber-200">CARRY20</code> at checkout for 20% off all handcrafted bags.
              </span>
            </div>
          </div>

        </div>

        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-stone-500 gap-4">
          <p>© {new Date().getFullYear()} bag.Ze Atelier. All rights reserved. Handcrafted in Italy.</p>
          <div className="flex items-center gap-6">
            <span className="hover:text-stone-400 cursor-pointer">Ethical Tuscan Tannery Certified</span>
            <span className="hover:text-stone-400 cursor-pointer">Lifetime Guarantee</span>
            <span className="hover:text-stone-400 cursor-pointer">Privacy & Terms</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
