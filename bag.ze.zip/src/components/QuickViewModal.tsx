import React, { useState, useEffect } from 'react';
import { X, Star, ShoppingBag, Volume2, VolumeX, Sparkles, Shield, Check, Ruler, Box, Stamp } from 'lucide-react';
import { Product, ProductColor } from '../types';

interface QuickViewModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product, color: ProductColor, quantity: number) => void;
  onOpenMonogram: (product: Product) => void;
}

export const QuickViewModal: React.FC<QuickViewModalProps> = ({
  product,
  onClose,
  onAddToCart,
  onOpenMonogram,
}) => {
  if (!product) return null;

  const [selectedColor, setSelectedColor] = useState<ProductColor>(product.colors[0]);
  const [quantity, setQuantity] = useState<number>(1);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [aiAdviceExpanded, setAiAdviceExpanded] = useState<boolean>(true);
  const [addedAnim, setAddedAnim] = useState<boolean>(false);

  // Stop speech synthesis on unmount or product change
  useEffect(() => {
    setSelectedColor(product.colors[0]);
    setQuantity(1);
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
    return () => {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, [product]);

  // Voice narration using SpeechSynthesis
  const handleToggleVoice = () => {
    if (!('speechSynthesis' in window)) {
      alert('Speech synthesis is not supported on your browser.');
      return;
    }

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    } else {
      window.speechSynthesis.cancel();
      const textToSpeak = `Introducing the ${product.name} from bag.Ze. ${product.tagline}. Crafted from ${product.materials}. ${product.stylingAdvice}. For care: ${product.careGuide}`;
      const utterance = new SpeechSynthesisUtterance(textToSpeak);
      utterance.rate = 0.95;
      utterance.pitch = 1.0;
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);

      // Select natural voice if available
      const voices = window.speechSynthesis.getVoices();
      const naturalVoice = voices.find((v) => v.lang.startsWith('en') && (v.name.includes('Natural') || v.name.includes('Premium') || v.name.includes('Google') || v.name.includes('Samantha')));
      if (naturalVoice) {
        utterance.voice = naturalVoice;
      }

      window.speechSynthesis.speak(utterance);
      setIsSpeaking(true);
    }
  };

  const handleAdd = () => {
    onAddToCart(product, selectedColor, quantity);
    setAddedAnim(true);
    setTimeout(() => {
      setAddedAnim(false);
    }, 1200);
  };

  return (
    <div
      id="quick-view-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-stone-950/70 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        id="quick-view-modal-content"
        className="bg-white rounded-3xl max-w-4xl w-full overflow-hidden shadow-2xl relative flex flex-col md:flex-row my-auto border border-stone-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          id="close-quick-view-btn"
          onClick={onClose}
          className="absolute top-4 right-4 z-20 w-9 h-9 rounded-full bg-white/90 hover:bg-stone-100 shadow-sm flex items-center justify-center text-stone-600 hover:text-stone-900 transition-colors cursor-pointer"
          title="Close dialog"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Left Column: Image & Badges */}
        <div className="w-full md:w-1/2 bg-stone-100 relative min-h-[300px] md:min-h-[500px] flex items-center justify-center overflow-hidden">
          <img
            src={selectedColor.image || product.image}
            alt={product.name}
            className="w-full h-full object-cover object-center"
          />

          <div className="absolute top-4 left-4 flex flex-col gap-1.5">
            <span className="px-3 py-1 bg-brand-900 text-amber-200 text-xs font-bold uppercase tracking-wider rounded-lg shadow-sm">
              bag.Ze Atelier
            </span>
            {product.isBestSeller && (
              <span className="px-2.5 py-0.5 bg-amber-600 text-white text-[10px] font-extrabold uppercase tracking-wider rounded-md w-fit">
                Bestseller
              </span>
            )}
          </div>

          <div className="absolute bottom-4 left-4 right-4 bg-white/90 backdrop-blur-md px-3.5 py-2 rounded-xl text-[11px] text-stone-700 flex items-center justify-between border border-stone-200/60">
            <span className="font-medium">Selected finish:</span>
            <span className="font-bold text-brand-900">{selectedColor.name}</span>
          </div>
        </div>

        {/* Right Column: Info, Specs, Audio & Actions */}
        <div className="w-full md:w-1/2 p-6 sm:p-8 flex flex-col justify-between overflow-y-auto max-h-[85vh]">
          <div>
            {/* Header info */}
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-bold text-brand-700 uppercase tracking-wider">
                {product.category}
              </span>
              <div className="flex items-center gap-1 text-amber-500 text-xs">
                <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                <span className="font-bold text-stone-800">{product.rating}</span>
                <span className="text-stone-400">({product.reviewCount} reviews)</span>
              </div>
            </div>

            <h2 className="font-serif text-2xl sm:text-3xl font-bold text-stone-900">
              {product.name}
            </h2>

            <div className="flex items-baseline gap-2 mt-2">
              <span className="text-2xl font-extrabold text-stone-900 font-mono">
                ${product.price}
              </span>
              {product.originalPrice && (
                <span className="text-sm text-stone-400 line-through font-mono">
                  ${product.originalPrice}
                </span>
              )}
              <span className="ml-2 text-xs font-semibold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">
                Free Worldwide Shipping
              </span>
            </div>

            <p className="text-xs sm:text-sm text-stone-600 mt-3 leading-relaxed">
              {product.description}
            </p>

            {/* Color selection */}
            <div className="mt-4 pt-3 border-t border-stone-100">
              <label className="block text-xs font-bold text-stone-700 mb-2">
                Select Color: <span className="font-normal text-stone-500">{selectedColor.name}</span>
              </label>
              <div className="flex items-center gap-2">
                {product.colors.map((c) => (
                  <button
                    key={c.name}
                    onClick={() => setSelectedColor(c)}
                    className={`flex items-center gap-2 px-3 py-1.5 rounded-xl border text-xs font-medium transition-all cursor-pointer ${
                      selectedColor.name === c.name
                        ? 'border-brand-700 bg-brand-50/60 text-brand-900 ring-1 ring-brand-700 font-bold'
                        : 'border-stone-200 hover:border-stone-400 text-stone-700'
                    }`}
                  >
                    <span
                      className="w-3.5 h-3.5 rounded-full border border-stone-300"
                      style={{ backgroundColor: c.hex }}
                    />
                    <span>{c.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Product Key Specifications */}
            <div className="grid grid-cols-2 gap-2 mt-4 p-3 bg-stone-50 rounded-xl text-[11px] text-stone-600 border border-stone-200/60">
              <div className="flex items-center gap-1.5">
                <Ruler className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                <span className="truncate">{product.dimensions}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Box className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                <span>{product.capacityLiters} Liters volume</span>
              </div>
              <div className="flex items-center gap-1.5 col-span-2">
                <Shield className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                <span className="truncate">{product.materials}</span>
              </div>
            </div>

            {/* ✨ Gemini AI Audio Voice & Styling Box */}
            <div className="mt-4 p-4 rounded-2xl bg-amber-50/70 border border-amber-200/80">
              <div className="flex items-center justify-between gap-2 flex-wrap mb-2">
                <div className="flex items-center gap-1.5 text-xs font-bold text-amber-950">
                  <Sparkles className="w-4 h-4 text-amber-600" />
                  <span>AI Styling & Audio Guide</span>
                </div>

                {/* Listen Voice Button */}
                <button
                  id="modal-audio-guide-btn"
                  onClick={handleToggleVoice}
                  className={`px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-xs ${
                    isSpeaking
                      ? 'bg-rose-600 hover:bg-rose-700 text-white animate-pulse'
                      : 'bg-brand-900 hover:bg-brand-800 text-amber-200'
                  }`}
                >
                  {isSpeaking ? (
                    <>
                      <VolumeX className="w-3.5 h-3.5" />
                      <span>Stop Voice</span>
                    </>
                  ) : (
                    <>
                      <Volume2 className="w-3.5 h-3.5 text-amber-300" />
                      <span>Listen to Guide</span>
                    </>
                  )}
                </button>
              </div>

              <div className="text-xs text-stone-700 space-y-2 leading-relaxed">
                <p>
                  <strong className="text-amber-900">Styling Advice:</strong> {product.stylingAdvice}
                </p>
                <p className="text-[11px] text-stone-500">
                  <strong className="text-stone-700">Leather Care:</strong> {product.careGuide}
                </p>
              </div>
            </div>
          </div>

          {/* Action Row */}
          <div className="mt-5 pt-4 border-t border-stone-200 space-y-2.5">
            <div className="flex items-center gap-3">
              {/* Quantity selector */}
              <div className="flex items-center border border-stone-200 rounded-xl bg-stone-50 overflow-hidden">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="px-3 py-2 text-stone-600 hover:bg-stone-200 text-sm font-bold cursor-pointer"
                >
                  -
                </button>
                <span className="px-3 py-2 text-xs font-bold text-stone-900 min-w-8 text-center font-mono">
                  {quantity}
                </span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="px-3 py-2 text-stone-600 hover:bg-stone-200 text-sm font-bold cursor-pointer"
                >
                  +
                </button>
              </div>

              {/* Add to Bag Button */}
              <button
                id="quick-view-add-to-cart-btn"
                onClick={handleAdd}
                className={`flex-1 py-3.5 px-4 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md ${
                  addedAnim
                    ? 'bg-emerald-600 text-white'
                    : 'bg-brand-900 hover:bg-brand-800 active:scale-98 text-white'
                }`}
              >
                {addedAnim ? (
                  <>
                    <Check className="w-4 h-4" />
                    <span>Added to Your Shopping Bag!</span>
                  </>
                ) : (
                  <>
                    <ShoppingBag className="w-4 h-4 text-amber-300" />
                    <span>Add {quantity > 1 ? `${quantity} Items` : 'to Bag'} • ${(product.price * quantity).toFixed(2)}</span>
                  </>
                )}
              </button>
            </div>

            {/* Custom Monogram Shortcut */}
            {product.canMonogram && (
              <button
                id="quick-view-monogram-shortcut-btn"
                onClick={() => {
                  onClose();
                  onOpenMonogram(product);
                }}
                className="w-full py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-semibold rounded-xl flex items-center justify-center gap-1.5 transition-colors cursor-pointer border border-stone-300/70"
              >
                <Stamp className="w-3.5 h-3.5 text-amber-700" />
                <span>Customize with Hot-Stamped Monogram Initials</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
