import React from 'react';
import { X, Heart, ShoppingBag, Trash2, ArrowRight } from 'lucide-react';
import { Product, ProductColor } from '../types';

interface WishlistModalProps {
  isOpen: boolean;
  onClose: () => void;
  wishlist: Product[];
  onRemoveFromWishlist: (product: Product) => void;
  onAddToCart: (product: Product, color: ProductColor) => void;
  onQuickView: (product: Product) => void;
}

export const WishlistModal: React.FC<WishlistModalProps> = ({
  isOpen,
  onClose,
  wishlist,
  onRemoveFromWishlist,
  onAddToCart,
  onQuickView,
}) => {
  if (!isOpen) return null;

  return (
    <div
      id="wishlist-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-stone-950/70 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        id="wishlist-modal-content"
        className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl relative my-auto border border-stone-200 max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          id="close-wishlist-btn"
          onClick={onClose}
          className="absolute top-5 right-5 text-stone-400 hover:text-stone-700 p-1.5 rounded-full hover:bg-stone-100 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-5">
          <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center shadow-xs">
            <Heart className="w-5 h-5 fill-rose-600" />
          </div>
          <div>
            <h2 className="font-serif text-2xl font-bold text-stone-900">
              Saved Favorites ({wishlist.length})
            </h2>
            <p className="text-xs text-stone-500">
              Bags you have saved from the bag.Ze handcrafted collection.
            </p>
          </div>
        </div>

        {wishlist.length === 0 ? (
          <div className="text-center py-12 px-4">
            <p className="text-xs text-stone-500">
              You haven't saved any bags yet. Tap the heart icon on any piece to keep track of your favorites.
            </p>
            <button
              onClick={onClose}
              className="mt-4 px-6 py-2.5 bg-brand-900 text-white text-xs font-bold rounded-full hover:bg-brand-800 transition-colors cursor-pointer"
            >
              Browse Collection
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {wishlist.map((product) => (
              <div
                key={product.id}
                className="p-3.5 rounded-2xl border border-stone-200 bg-stone-50/50 flex items-center gap-3.5 justify-between"
              >
                <div
                  className="flex items-center gap-3 cursor-pointer min-w-0"
                  onClick={() => {
                    onClose();
                    onQuickView(product);
                  }}
                >
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-16 h-16 rounded-xl object-cover border border-stone-200 shrink-0"
                  />
                  <div className="min-w-0">
                    <span className="text-[10px] font-bold text-brand-700 uppercase">
                      {product.category}
                    </span>
                    <h4 className="font-serif font-bold text-stone-900 text-sm truncate">
                      {product.name}
                    </h4>
                    <span className="font-mono font-bold text-stone-800 text-xs">
                      ${product.price}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => {
                      onAddToCart(product, product.colors[0]);
                    }}
                    className="px-3 py-1.5 bg-brand-900 hover:bg-brand-800 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <ShoppingBag className="w-3.5 h-3.5 text-amber-300" />
                    <span className="hidden sm:inline">Add to Bag</span>
                  </button>

                  <button
                    onClick={() => onRemoveFromWishlist(product)}
                    className="p-2 text-stone-400 hover:text-rose-600 transition-colors cursor-pointer"
                    title="Remove from favorites"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
