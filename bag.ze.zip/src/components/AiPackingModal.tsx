import React, { useState } from 'react';
import { X, Compass, CheckSquare, Square, Volume2, VolumeX, Loader2, Sparkles, Check, Luggage } from 'lucide-react';
import { Product } from '../types';

interface AiPackingModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  onOpenQuickView: (product: Product) => void;
}

interface ChecklistItem {
  id: string;
  name: string;
  category: string;
  packed: boolean;
}

export const AiPackingModal: React.FC<AiPackingModalProps> = ({
  isOpen,
  onClose,
  products,
}) => {
  if (!isOpen) return null;

  // Filter bags with at least 15L capacity for travel packing
  const travelBags = products.filter((p) => p.capacityLiters >= 10);
  const [selectedBagId, setSelectedBagId] = useState<string>(travelBags[0]?.id || products[0].id);
  const [destination, setDestination] = useState<string>('Tokyo, Japan');
  const [tripDays, setTripDays] = useState<number>(4);
  const [weather, setWeather] = useState<string>('Mild Spring (18°C)');
  const [loading, setLoading] = useState<boolean>(false);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);

  const selectedBag = products.find((p) => p.id === selectedBagId) || products[0];

  const [checklist, setChecklist] = useState<ChecklistItem[]>([
    { id: '1', name: '4x Merino wool & cotton shirts (rolled)', category: 'Clothing', packed: true },
    { id: '2', name: '2x Tailored trousers & dark selvedge denim', category: 'Clothing', packed: true },
    { id: '3', name: '1x Lightweight water-repellent jacket', category: 'Clothing', packed: false },
    { id: '4', name: '5x Undergarments & merino socks', category: 'Clothing', packed: false },
    { id: '5', name: '15" Laptop, magnetic cables, universal adapter', category: 'Tech', packed: false },
    { id: '6', name: 'Noise-canceling headphones & e-reader', category: 'Tech', packed: false },
    { id: '7', name: 'TSA clear 100ml dopp kit (creams, cologne)', category: 'Toiletries', packed: false },
    { id: '8', name: 'Passport, bag.Ze leather wallet, travel cards', category: 'Essentials', packed: true },
    { id: '9', name: 'Foldable umbrella & sunglasses', category: 'Essentials', packed: false },
  ]);

  const [advice, setAdvice] = useState<string>(
    `Your ${selectedBag.name} (${selectedBag.capacityLiters}L) is ideal for a ${tripDays}-day getaway to ${destination}. Pack rolled garments along the bottom spine, keep the heavy shoes in the separate compartment, and slide your laptop flat in the rear padded sleeve.`
  );

  const [volumePercent, setVolumePercent] = useState<number>(78);

  const handleGeneratePlan = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const res = await fetch('/api/ai/packing', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          bagName: selectedBag.name,
          capacityLiters: selectedBag.capacityLiters,
          destination,
          tripDays,
          weather,
        }),
      });

      if (!res.ok) throw new Error('Failed to generate packing plan');
      const data = await res.json();

      if (data.checklist) {
        setChecklist(
          data.checklist.map((item: any, idx: number) => ({
            id: String(idx + 1),
            name: item.name,
            category: item.category || 'General',
            packed: false,
          }))
        );
      }
      if (data.conciergeAdvice) {
        setAdvice(data.conciergeAdvice);
      }
      if (data.estimatedVolumePercent) {
        setVolumePercent(data.estimatedVolumePercent);
      }
    } catch (err) {
      console.error(err);
      // Heuristic fallback calculation
      const calculatedVol = Math.min(95, Math.max(40, Math.round((tripDays * 9.5 * 100) / selectedBag.capacityLiters)));
      setVolumePercent(calculatedVol);
      setAdvice(
        `Optimized for ${tripDays} days in ${destination}: place dense footwear and toiletry pouches against the bottom base of the ${selectedBag.name}, and utilize interior mesh pockets for chargers and small essentials.`
      );
    } finally {
      setLoading(false);
    }
  };

  const toggleItem = (id: string) => {
    setChecklist((prev) =>
      prev.map((item) => (item.id === id ? { ...item, packed: !item.packed } : item))
    );
  };

  const handleToggleVoice = () => {
    if (!('speechSynthesis' in window)) return;
    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    } else {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(advice);
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);
      window.speechSynthesis.speak(utterance);
      setIsSpeaking(true);
    }
  };

  const packedCount = checklist.filter((i) => i.packed).length;
  const progressPercent = Math.round((packedCount / checklist.length) * 100);

  return (
    <div
      id="ai-packing-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-stone-950/70 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        id="ai-packing-modal-content"
        className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl relative my-auto border border-stone-200 max-h-[92vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          id="close-ai-packing-btn"
          onClick={onClose}
          className="absolute top-5 right-5 text-stone-400 hover:text-stone-700 p-1.5 rounded-full hover:bg-stone-100 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3.5 mb-5">
          <div className="w-12 h-12 rounded-2xl bg-brand-900 text-amber-200 flex items-center justify-center text-xl shadow-md shrink-0">
            <Compass className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[10px] font-extrabold uppercase tracking-widest text-brand-700 bg-brand-50 px-2 py-0.5 rounded-sm">
              Smart Travel Concierge
            </span>
            <h2 className="font-serif text-2xl font-bold text-stone-900 mt-0.5">
              AI Bag Packing & Capacity Planner
            </h2>
            <p className="text-xs text-stone-500">
              Calculate capacity volume and get a tailored checklist for your journey.
            </p>
          </div>
        </div>

        {/* Configuration Form */}
        <form onSubmit={handleGeneratePlan} className="space-y-4 mb-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                Select Your bag.Ze Bag
              </label>
              <select
                value={selectedBagId}
                onChange={(e) => setSelectedBagId(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-stone-50 border border-stone-200 text-xs focus:bg-white focus:border-brand-500 focus:outline-none transition-all cursor-pointer font-medium"
              >
                {travelBags.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name} ({b.capacityLiters}L • {b.category})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                Destination
              </label>
              <input
                type="text"
                value={destination}
                onChange={(e) => setDestination(e.target.value)}
                placeholder="e.g. London, Florence, New York"
                className="w-full px-3.5 py-2.5 rounded-xl bg-stone-50 border border-stone-200 text-xs focus:bg-white focus:border-brand-500 focus:outline-none transition-all"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                Trip Duration: <span className="font-mono text-brand-700">{tripDays} Days</span>
              </label>
              <input
                type="range"
                min="1"
                max="14"
                value={tripDays}
                onChange={(e) => setTripDays(Number(e.target.value))}
                className="w-full accent-brand-700 cursor-pointer"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                Expected Weather
              </label>
              <select
                value={weather}
                onChange={(e) => setWeather(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-stone-50 border border-stone-200 text-xs focus:bg-white focus:border-brand-500 focus:outline-none transition-all cursor-pointer"
              >
                <option value="Mild Spring / Autumn">Mild Spring / Autumn (15°C - 20°C)</option>
                <option value="Warm Summer">Warm Summer (25°C - 32°C)</option>
                <option value="Cold Winter">Cold Winter & Layers (0°C - 8°C)</option>
                <option value="Rainy & Variable">Rainy & Humid / Variable</option>
              </select>
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-2.5 px-4 bg-brand-900 hover:bg-brand-800 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer disabled:opacity-75"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin text-amber-300" />
                <span>Calculating Capacity & Packing List...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>Generate Smart Packing Plan</span>
              </>
            )}
          </button>
        </form>

        {/* Capacity & Bag Overview Banner */}
        <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-3 mb-6">
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <Luggage className="w-4 h-4 text-brand-700" />
              <span className="font-bold text-stone-900">{selectedBag.name}</span>
              <span className="text-stone-400">({selectedBag.capacityLiters}L Volume)</span>
            </div>
            <span className="font-bold font-mono text-brand-800">{volumePercent}% Capacity Filled</span>
          </div>

          {/* Volume progress bar */}
          <div className="w-full bg-stone-200 h-2.5 rounded-full overflow-hidden">
            <div
              className={`h-full transition-all duration-500 rounded-full ${
                volumePercent > 90
                  ? 'bg-amber-600'
                  : volumePercent > 70
                  ? 'bg-brand-600'
                  : 'bg-emerald-600'
              }`}
              style={{ width: `${volumePercent}%` }}
            ></div>
          </div>

          <div className="flex items-center justify-between text-[11px] text-stone-500 pt-1">
            <span>Carry-On Status: <strong className="text-emerald-700 font-semibold">TSA Overhead Bin Approved</strong></span>
            <span>Estimated Weight: <strong className="text-stone-700">{Math.round(tripDays * 1.8 + 2.5)} lbs</strong></span>
          </div>
        </div>

        {/* Concierge Advice with Voice TTS */}
        <div className="p-4 rounded-2xl bg-amber-50/80 border border-amber-200/80 mb-6">
          <div className="flex items-center justify-between gap-2 mb-2">
            <span className="text-xs font-bold text-amber-950 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              Concierge Packing Guide
            </span>
            <button
              onClick={handleToggleVoice}
              className={`px-2.5 py-1 rounded-full text-[11px] font-bold flex items-center gap-1 transition-all cursor-pointer ${
                isSpeaking ? 'bg-rose-600 text-white animate-pulse' : 'bg-brand-900 text-amber-200 hover:bg-brand-800'
              }`}
            >
              {isSpeaking ? (
                <>
                  <VolumeX className="w-3 h-3" /> Stop
                </>
              ) : (
                <>
                  <Volume2 className="w-3 h-3 text-amber-300" /> Listen Tips
                </>
              )}
            </button>
          </div>
          <p className="text-xs text-stone-700 leading-relaxed">
            {advice}
          </p>
        </div>

        {/* Interactive Checklist */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-stone-900 text-xs uppercase tracking-wider">
              Packing Checklist ({packedCount}/{checklist.length} packed)
            </h3>
            <span className="text-xs font-bold font-mono text-brand-700">
              {progressPercent}% ready
            </span>
          </div>

          <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
            {checklist.map((item) => (
              <div
                key={item.id}
                onClick={() => toggleItem(item.id)}
                className={`p-2.5 rounded-xl border flex items-center justify-between gap-2 cursor-pointer transition-colors ${
                  item.packed
                    ? 'bg-emerald-50/60 border-emerald-200 text-emerald-950'
                    : 'bg-white border-stone-200 text-stone-800 hover:bg-stone-50'
                }`}
              >
                <div className="flex items-center gap-2.5 text-xs">
                  {item.packed ? (
                    <CheckSquare className="w-4 h-4 text-emerald-600 shrink-0" />
                  ) : (
                    <Square className="w-4 h-4 text-stone-400 shrink-0" />
                  )}
                  <span className={item.packed ? 'line-through text-stone-500 font-medium' : 'font-medium'}>
                    {item.name}
                  </span>
                </div>
                <span className="text-[10px] uppercase font-bold text-stone-400 bg-stone-100 px-2 py-0.5 rounded">
                  {item.category}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
