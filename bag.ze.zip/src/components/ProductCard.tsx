import React, { useState } from 'react';
import { Heart, Star, Eye, ShoppingBag, Check, Sparkles } from 'lucide-react';
import { Product, ProductColor } from '../types';

interface ProductCardProps {
  product: Product;
  isWishlisted: boolean;
  onToggleWishlist: (product: Product) => void;
  onQuickView: (product: Product) => void;
  onAddToCart: (product: Product, selectedColor: ProductColor) => void;
  onMonogramCustomizer?: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  isWishlisted,
  onToggleWishlist,
  onQuickView,
  onAddToCart,
}) => {
  const [selectedColor, setSelectedColor] = useState<ProductColor>(product.colors[0]);
  const [addedAnim, setAddedAnim] = useState(false);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    onAddToCart(product, selectedColor);
    setAddedAnim(true);
    setTimeout(() => setAddedAnim(false), 1500);
  };

  return (
    <div
      id={`product-card-${product.id}`}
      className="group bg-white rounded-2xl border border-stone-200/80 overflow-hidden shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col justify-between"
    >
      {/* Product Image Area */}
      <div className="relative bg-stone-100 aspect-4/3 overflow-hidden cursor-pointer" onClick={() => onQuickView(product)}>
        <img
          src={selectedColor.image || product.image}
          alt={product.name}
          className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
        />

        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-1.5 z-10">
          {product.isBestSeller && (
            <span className="px-2.5 py-0.5 bg-brand-900 text-amber-200 text-[10px] font-extrabold uppercase tracking-wider rounded-md shadow-xs">
              Best Seller
            </span>
          )}
          {product.isNew && (
            <span className="px-2.5 py-0.5 bg-amber-600 text-white text-[10px] font-extrabold uppercase tracking-wider rounded-md shadow-xs">
              New Arrival
            </span>
          )}
          {product.canMonogram && (
            <span className="px-2 py-0.5 bg-white/90 backdrop-blur-xs text-stone-800 text-[9px] font-bold rounded-md shadow-xs border border-stone-200 flex items-center gap-1">
              <Sparkles className="w-2.5 h-2.5 text-amber-600" /> Monogrammable
            </span>
          )}
        </div>

        {/* Wishlist Heart Button */}
        <button
          id={`wishlist-btn-${product.id}`}
          onClick={(e) => {
            e.stopPropagation();
            onToggleWishlist(product);
          }}
          className={`absolute top-3 right-3 w-8 h-8 rounded-full flex items-center justify-center transition-all z-10 cursor-pointer shadow-sm ${
            isWishlisted
              ? 'bg-rose-50 text-rose-600 ring-1 ring-rose-300'
              : 'bg-white/90 text-stone-600 hover:text-rose-600 hover:bg-white'
          }`}
          title={isWishlisted ? 'Remove from wishlist' : 'Save to wishlist'}
        >
          <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-rose-600' : ''}`} />
        </button>

        {/* Quick View Button on Hover */}
        <div className="absolute inset-x-3 bottom-3 opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex items-center justify-center gap-2">
          <button
            id={`quick-view-btn-${product.id}`}
            onClick={(e) => {
              e.stopPropagation();
              onQuickView(product);
            }}
            className="w-full py-2 bg-white/95 hover:bg-white text-stone-800 text-xs font-bold rounded-xl shadow-md backdrop-blur-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer border border-stone-200"
          >
            <Eye className="w-3.5 h-3.5 text-brand-700" />
            <span>Quick View & Voice Guide</span>
          </button>
        </div>
      </div>

      {/* Product Details Area */}
      <div className="p-4 sm:p-5 flex flex-col flex-1 justify-between gap-3">
        <div>
          {/* Category & Rating */}
          <div className="flex items-center justify-between text-xs text-stone-500 mb-1.5">
            <span className="font-semibold text-brand-700 uppercase text-[10px] tracking-wider">
              {product.category}
            </span>
            <div className="flex items-center gap-1 text-amber-500">
              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
              <span className="font-bold text-stone-700 text-xs">{product.rating}</span>
              <span className="text-stone-400 text-[10px]">({product.reviewCount})</span>
            </div>
          </div>

          {/* Product Name */}
          <h3
            onClick={() => onQuickView(product)}
            className="font-serif text-lg font-bold text-stone-900 group-hover:text-brand-700 transition-colors cursor-pointer line-clamp-1"
          >
            {product.name}
          </h3>

          <p className="text-xs text-stone-500 mt-1 line-clamp-2 leading-relaxed">
            {product.tagline}
          </p>

          {/* Capacity and Specs Tag */}
          <div className="mt-2.5 flex items-center gap-2 text-[11px] text-stone-500 font-medium">
            <span className="bg-stone-100 px-2 py-0.5 rounded-md text-stone-700">
              {product.capacityLiters} Liters
            </span>
            <span className="text-stone-300">•</span>
            <span className="truncate">{product.weight}</span>
          </div>
        </div>

        {/* Color Swatches */}
        <div className="pt-2 border-t border-stone-100">
          <div className="flex items-center justify-between gap-2 mb-3">
            <span className="text-[11px] text-stone-400 truncate">
              Color: <strong className="text-stone-700 font-medium">{selectedColor.name}</strong>
            </span>
            <div className="flex items-center gap-1.5">
              {product.colors.map((color) => (
                <button
                  key={color.name}
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedColor(color);
                  }}
                  className={`w-4 h-4 rounded-full border transition-all cursor-pointer ${
                    selectedColor.name === color.name
                      ? 'ring-2 ring-brand-700 scale-110 border-white'
                      : 'border-stone-300 hover:scale-105'
                  }`}
                  style={{ backgroundColor: color.hex }}
                  title={color.name}
                />
              ))}
            </div>
          </div>

          {/* Price & Add to Bag CTA */}
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-baseline gap-1.5">
              <span className="text-lg font-extrabold text-stone-900 font-mono">
                ${product.price}
              </span>
              {product.originalPrice && (
                <span className="text-xs text-stone-400 line-through font-mono">
                  ${product.originalPrice}
                </span>
              )}
            </div>

            <button
              id={`add-to-cart-btn-${product.id}`}
              onClick={handleAddToCart}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-xs ${
                addedAnim
                  ? 'bg-emerald-600 text-white'
                  : 'bg-brand-900 hover:bg-brand-800 active:scale-95 text-white'
              }`}
            >
              {addedAnim ? (
                <>
                  <Check className="w-3.5 h-3.5" />
                  <span>Added!</span>
                </>
              ) : (
                <>
                  <ShoppingBag className="w-3.5 h-3.5 text-amber-300" />
                  <span>Add to Bag</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
