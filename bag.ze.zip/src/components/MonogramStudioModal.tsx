import React, { useState } from 'react';
import { X, Stamp, Sparkles, Check, ShoppingBag, Gift } from 'lucide-react';
import { Product, ProductColor } from '../types';

interface MonogramStudioModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  initialProduct?: Product | null;
  onAddToCartWithMonogram: (
    product: Product,
    color: ProductColor,
    monogram: { initials: string; finish: 'gold' | 'silver' | 'blind' }
  ) => void;
}

export const MonogramStudioModal: React.FC<MonogramStudioModalProps> = ({
  isOpen,
  onClose,
  products,
  initialProduct,
  onAddToCartWithMonogram,
}) => {
  if (!isOpen) return null;

  const eligibleProducts = products.filter((p) => p.canMonogram !== false);
  const [selectedProduct, setSelectedProduct] = useState<Product>(
    initialProduct && initialProduct.canMonogram !== false
      ? initialProduct
      : eligibleProducts[0] || products[0]
  );
  const [selectedColor, setSelectedColor] = useState<ProductColor>(
    selectedProduct.colors[0]
  );
  const [initials, setInitials] = useState<string>('B.Z.');
  const [finish, setFinish] = useState<'gold' | 'silver' | 'blind'>('gold');
  const [added, setAdded] = useState<boolean>(false);

  const handleInitialsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value.toUpperCase().slice(0, 4);
    setInitials(val);
  };

  const handleProductChange = (prodId: string) => {
    const found = products.find((p) => p.id === prodId);
    if (found) {
      setSelectedProduct(found);
      setSelectedColor(found.colors[0]);
    }
  };

  const handleAdd = () => {
    onAddToCartWithMonogram(selectedProduct, selectedColor, {
      initials: initials || 'BZ',
      finish,
    });
    setAdded(true);
    setTimeout(() => {
      setAdded(false);
      onClose();
    }, 1200);
  };

  return (
    <div
      id="monogram-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-stone-950/70 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        id="monogram-modal-content"
        className="bg-white rounded-3xl max-w-3xl w-full p-6 sm:p-8 shadow-2xl relative my-auto border border-stone-200 max-h-[92vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          id="close-monogram-btn"
          onClick={onClose}
          className="absolute top-5 right-5 text-stone-400 hover:text-stone-700 p-1.5 rounded-full hover:bg-stone-100 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3.5 mb-6">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-700 via-amber-800 to-amber-950 text-amber-200 flex items-center justify-center text-xl shadow-md ring-1 ring-amber-400/40 shrink-0">
            <Stamp className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[10px] font-extrabold uppercase tracking-widest text-amber-800 bg-amber-100 px-2 py-0.5 rounded-sm">
              Complimentary Atelier Service
            </span>
            <h2 className="font-serif text-2xl font-bold text-stone-900 mt-0.5">
              Custom Monogram & Gift Studio
            </h2>
            <p className="text-xs text-stone-500">
              Personalize your bag.Ze leather piece with hot-stamped archival foil or blind debossing.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
          {/* Live Preview Canvas on Leather Swatch */}
          <div className="bg-stone-900 rounded-2xl p-6 sm:p-8 flex flex-col items-center justify-center relative overflow-hidden border border-stone-800 shadow-inner min-h-[280px]">
            {/* Leather texture simulation */}
            <div
              className="w-48 h-48 sm:w-56 sm:h-56 rounded-2xl relative shadow-2xl flex flex-col items-center justify-center p-4 border border-white/10 transition-all duration-300"
              style={{
                backgroundColor: selectedColor.hex || '#63442a',
                boxShadow: 'inset 0 0 40px rgba(0,0,0,0.6), 0 20px 30px rgba(0,0,0,0.4)',
              }}
            >
              {/* Stitching border */}
              <div className="absolute inset-3 border border-dashed border-stone-400/40 rounded-xl pointer-events-none"></div>

              <div className="text-[9px] uppercase tracking-widest text-white/50 font-bold mb-4 font-sans">
                bag.Ze Atelier
              </div>

              {/* Hot stamped initials with realistic foil styling */}
              <div
                className={`font-serif text-4xl sm:text-5xl font-extrabold tracking-wider select-none transition-all ${
                  finish === 'gold'
                    ? 'text-transparent bg-clip-text bg-gradient-to-br from-amber-200 via-amber-300 to-amber-500 drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]'
                    : finish === 'silver'
                    ? 'text-transparent bg-clip-text bg-gradient-to-br from-stone-100 via-stone-200 to-stone-400 drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]'
                    : 'text-black/40 drop-shadow-[0_1px_0px_rgba(255,255,255,0.2)]'
                }`}
                style={{
                  textShadow:
                    finish === 'blind'
                      ? 'inset 0 2px 4px rgba(0,0,0,0.9), 0 1px 1px rgba(255,255,255,0.2)'
                      : undefined,
                }}
              >
                {initials || 'BZ'}
              </div>

              <div className="mt-4 text-[10px] text-white/70 font-mono tracking-widest uppercase">
                {finish === 'gold' && '24K Gold Foil'}
                {finish === 'silver' && 'Sterling Silver'}
                {finish === 'blind' && 'Blind Debossed'}
              </div>
            </div>

            <div className="mt-4 flex items-center gap-1 text-[11px] text-amber-200/80">
              <Sparkles className="w-3 h-3 text-amber-300" />
              <span>Hand-stamped in Florence, Italy</span>
            </div>
          </div>

          {/* Configuration Form Controls */}
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                Select Bag Model
              </label>
              <select
                value={selectedProduct.id}
                onChange={(e) => handleProductChange(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-stone-50 border border-stone-200 text-xs focus:bg-white focus:border-brand-500 focus:outline-none transition-all cursor-pointer font-medium"
              >
                {eligibleProducts.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} (${p.price})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                Leather Color
              </label>
              <div className="flex items-center gap-2">
                {selectedProduct.colors.map((c) => (
                  <button
                    key={c.name}
                    onClick={() => setSelectedColor(c)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-medium cursor-pointer transition-all ${
                      selectedColor.name === c.name
                        ? 'border-brand-700 bg-brand-50 text-brand-900 font-bold ring-1 ring-brand-700'
                        : 'border-stone-200 text-stone-700 hover:border-stone-300'
                    }`}
                  >
                    <span
                      className="w-3 h-3 rounded-full border border-stone-300"
                      style={{ backgroundColor: c.hex }}
                    />
                    <span className="text-[11px]">{c.name}</span>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                Enter Initials (Up to 4 characters)
              </label>
              <input
                type="text"
                value={initials}
                onChange={handleInitialsChange}
                placeholder="e.g. B.Z."
                maxLength={4}
                className="w-full px-4 py-2.5 rounded-xl bg-stone-50 border border-stone-200 text-sm font-bold tracking-widest uppercase focus:bg-white focus:border-brand-500 focus:outline-none transition-all font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1.5">
                Stamping Foil Finish
              </label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setFinish('gold')}
                  className={`p-2.5 rounded-xl border text-center text-xs font-bold cursor-pointer transition-all ${
                    finish === 'gold'
                      ? 'border-amber-500 bg-amber-50 text-amber-900 ring-1 ring-amber-500'
                      : 'border-stone-200 text-stone-600 hover:border-stone-300'
                  }`}
                >
                  <div className="w-4 h-4 rounded-full bg-amber-400 mx-auto mb-1 border border-amber-600/30"></div>
                  <span>24K Gold</span>
                </button>

                <button
                  type="button"
                  onClick={() => setFinish('silver')}
                  className={`p-2.5 rounded-xl border text-center text-xs font-bold cursor-pointer transition-all ${
                    finish === 'silver'
                      ? 'border-stone-400 bg-stone-100 text-stone-900 ring-1 ring-stone-400'
                      : 'border-stone-200 text-stone-600 hover:border-stone-300'
                  }`}
                >
                  <div className="w-4 h-4 rounded-full bg-stone-300 mx-auto mb-1 border border-stone-400"></div>
                  <span>Silver Foil</span>
                </button>

                <button
                  type="button"
                  onClick={() => setFinish('blind')}
                  className={`p-2.5 rounded-xl border text-center text-xs font-bold cursor-pointer transition-all ${
                    finish === 'blind'
                      ? 'border-stone-800 bg-stone-800 text-white ring-1 ring-stone-800'
                      : 'border-stone-200 text-stone-600 hover:border-stone-300'
                  }`}
                >
                  <div className="w-4 h-4 rounded-full bg-stone-700 mx-auto mb-1 border border-stone-800"></div>
                  <span>Debossed</span>
                </button>
              </div>
            </div>

            <div className="pt-2">
              <button
                id="add-monogram-to-bag-btn"
                onClick={handleAdd}
                className={`w-full py-3.5 px-4 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md ${
                  added
                    ? 'bg-emerald-600 text-white'
                    : 'bg-brand-900 hover:bg-brand-800 active:scale-98 text-white'
                }`}
              >
                {added ? (
                  <>
                    <Check className="w-4 h-4" />
                    <span>Added Custom Monogram to Shopping Bag!</span>
                  </>
                ) : (
                  <>
                    <ShoppingBag className="w-4 h-4 text-amber-300" />
                    <span>Add {selectedProduct.name} with Monogram • ${selectedProduct.price}</span>
                  </>
                )}
              </button>
              <p className="text-[10px] text-stone-400 text-center mt-2 flex items-center justify-center gap-1">
                <Gift className="w-3 h-3 text-amber-600" />
                <span>Monogramming is 100% complimentary & includes luxury gift packaging</span>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
