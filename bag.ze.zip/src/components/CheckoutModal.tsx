import React, { useState } from 'react';
import { X, CheckCircle2, ShieldCheck, CreditCard, Truck, Lock, ArrowRight, ShoppingBag } from 'lucide-react';
import { CartItem } from '../types';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  discountPercent: number;
  onOrderCompleted: () => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  items,
  discountPercent,
  onOrderCompleted,
}) => {
  if (!isOpen) return null;

  const [step, setStep] = useState<'form' | 'success'>('form');
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: 'Sarah Jenkins',
    email: 'sarah.jenkins@example.com',
    address: '742 Evergreen Terrace',
    city: 'Seattle',
    postalCode: '98101',
    country: 'United States',
    cardNumber: '•••• •••• •••• 4242',
    expDate: '12/28',
    cvv: '883',
  });

  const subtotal = items.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const discountAmount = (subtotal * discountPercent) / 100;
  const isFreeShipping = subtotal >= 150;
  const shippingCost = isFreeShipping ? 0 : 25;
  const total = Math.max(0, subtotal - discountAmount + shippingCost);

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setStep('success');
      onOrderCompleted();
    }, 1500);
  };

  return (
    <div
      id="checkout-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-stone-950/70 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        id="checkout-modal-content"
        className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl relative my-auto border border-stone-200 max-h-[92vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          id="close-checkout-modal-btn"
          onClick={onClose}
          className="absolute top-5 right-5 text-stone-400 hover:text-stone-700 p-1.5 rounded-full hover:bg-stone-100 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {step === 'form' ? (
          <div>
            <div className="flex items-center gap-2.5 mb-5">
              <div className="w-10 h-10 rounded-xl bg-brand-900 text-amber-200 flex items-center justify-center font-serif text-base font-bold">
                bZ
              </div>
              <div>
                <h2 className="font-serif text-2xl font-bold text-stone-900">
                  Secure Checkout
                </h2>
                <p className="text-xs text-stone-500">
                  Encrypted 256-bit SSL transaction for bag.Ze Atelier
                </p>
              </div>
            </div>

            {/* Quick summary strip */}
            <div className="p-3.5 bg-stone-50 rounded-2xl border border-stone-200 mb-6 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-4 h-4 text-brand-700" />
                <span className="font-medium text-stone-700">
                  {items.length} unique items ({items.reduce((s, i) => s + i.quantity, 0)} total)
                </span>
              </div>
              <span className="font-mono font-bold text-brand-900 text-sm">
                Total: ${total.toFixed(2)}
              </span>
            </div>

            <form onSubmit={handleSubmitOrder} className="space-y-4">
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-stone-400 mb-2">
                  1. Shipping Information
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-stone-700 mb-1">
                      Full Name
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:bg-white focus:border-brand-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-stone-700 mb-1">
                      Email Address
                    </label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:bg-white focus:border-brand-500"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-[11px] font-semibold text-stone-700 mb-1">
                      Street Address
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.address}
                      onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                      className="w-full px-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:bg-white focus:border-brand-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-stone-700 mb-1">
                      City
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.city}
                      onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                      className="w-full px-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:bg-white focus:border-brand-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-stone-700 mb-1">
                      Country
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.country}
                      onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                      className="w-full px-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:bg-white focus:border-brand-500"
                    />
                  </div>
                </div>
              </div>

              <div className="pt-2">
                <h3 className="text-xs font-bold uppercase tracking-wider text-stone-400 mb-2">
                  2. Payment Method
                </h3>
                <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-3">
                  <div className="flex items-center justify-between text-xs text-stone-800">
                    <span className="flex items-center gap-1.5 font-bold">
                      <CreditCard className="w-4 h-4 text-brand-700" />
                      Credit / Debit Card
                    </span>
                    <span className="text-[10px] text-stone-400">SSL Encrypted</span>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <div className="col-span-2">
                      <input
                        type="text"
                        value={formData.cardNumber}
                        onChange={(e) => setFormData({ ...formData, cardNumber: e.target.value })}
                        className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-mono text-stone-800"
                      />
                    </div>
                    <div>
                      <input
                        type="text"
                        value={formData.expDate}
                        onChange={(e) => setFormData({ ...formData, expDate: e.target.value })}
                        className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-mono text-stone-800"
                        placeholder="MM/YY"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-4 bg-brand-900 hover:bg-brand-800 active:scale-98 text-white font-bold rounded-xl text-sm flex items-center justify-center gap-2 shadow-lg transition-all cursor-pointer disabled:opacity-70"
              >
                {loading ? (
                  <span>Securing Order & Processing with Bank...</span>
                ) : (
                  <>
                    <Lock className="w-4 h-4 text-amber-300" />
                    <span>Authorize & Place Order • ${total.toFixed(2)}</span>
                  </>
                )}
              </button>

              <p className="text-[10px] text-stone-400 text-center flex items-center justify-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>30-Day Money Back Guarantee • Lifetime Stitching Warranty</span>
              </p>
            </form>
          </div>
        ) : (
          <div className="text-center py-8 space-y-4 animate-in zoom-in-95 duration-200">
            <div className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto shadow-sm ring-8 ring-emerald-50">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <span className="text-[10px] font-extrabold uppercase tracking-widest text-emerald-700 bg-emerald-100 px-2.5 py-0.5 rounded-full">
              Order Confirmed #BZ-{Math.floor(100000 + Math.random() * 900000)}
            </span>

            <h2 className="font-serif text-3xl font-bold text-stone-900">
              Thank You, {formData.name.split(' ')[0]}!
            </h2>

            <p className="text-xs text-stone-600 max-w-md mx-auto leading-relaxed">
              Your handcrafted bag.Ze leather order has been received at our Tuscan Atelier. A confirmation receipt and live tracking details have been dispatched to <strong className="text-stone-900">{formData.email}</strong>.
            </p>

            <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 text-xs text-left max-w-md mx-auto space-y-2">
              <div className="flex items-center gap-2 text-stone-800 font-semibold">
                <Truck className="w-4 h-4 text-brand-700" />
                <span>DHL Express International Airway: 2-3 Business Days</span>
              </div>
              <p className="text-[11px] text-stone-500">
                Each bag is meticulously inspected, condition-treated with organic beeswax balm, and nestled in an archival breathable cotton dustbag with luxury gift ribbon.
              </p>
            </div>

            <button
              onClick={onClose}
              className="mt-4 px-8 py-3.5 bg-brand-900 hover:bg-brand-800 text-white text-xs font-bold rounded-full transition-all shadow-md cursor-pointer"
            >
              Continue Exploring bag.Ze
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
